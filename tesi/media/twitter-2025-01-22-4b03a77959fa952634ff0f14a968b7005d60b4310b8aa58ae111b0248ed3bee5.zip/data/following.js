window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "1626936328045883392",
      "userLink" : "https://twitter.com/intent/user?user_id=1626936328045883392"
    }
  },
  {
    "following" : {
      "accountId" : "1597692893820588033",
      "userLink" : "https://twitter.com/intent/user?user_id=1597692893820588033"
    }
  },
  {
    "following" : {
      "accountId" : "756671416574050308",
      "userLink" : "https://twitter.com/intent/user?user_id=756671416574050308"
    }
  },
  {
    "following" : {
      "accountId" : "67558466",
      "userLink" : "https://twitter.com/intent/user?user_id=67558466"
    }
  },
  {
    "following" : {
      "accountId" : "1654403648598802436",
      "userLink" : "https://twitter.com/intent/user?user_id=1654403648598802436"
    }
  },
  {
    "following" : {
      "accountId" : "81796885",
      "userLink" : "https://twitter.com/intent/user?user_id=81796885"
    }
  },
  {
    "following" : {
      "accountId" : "1437539711938023430",
      "userLink" : "https://twitter.com/intent/user?user_id=1437539711938023430"
    }
  },
  {
    "following" : {
      "accountId" : "1111128260480425985",
      "userLink" : "https://twitter.com/intent/user?user_id=1111128260480425985"
    }
  },
  {
    "following" : {
      "accountId" : "1133618449",
      "userLink" : "https://twitter.com/intent/user?user_id=1133618449"
    }
  },
  {
    "following" : {
      "accountId" : "1000976205431103489",
      "userLink" : "https://twitter.com/intent/user?user_id=1000976205431103489"
    }
  },
  {
    "following" : {
      "accountId" : "1042642691790696448",
      "userLink" : "https://twitter.com/intent/user?user_id=1042642691790696448"
    }
  },
  {
    "following" : {
      "accountId" : "1452622099",
      "userLink" : "https://twitter.com/intent/user?user_id=1452622099"
    }
  },
  {
    "following" : {
      "accountId" : "1028404157898797057",
      "userLink" : "https://twitter.com/intent/user?user_id=1028404157898797057"
    }
  },
  {
    "following" : {
      "accountId" : "185578414",
      "userLink" : "https://twitter.com/intent/user?user_id=185578414"
    }
  },
  {
    "following" : {
      "accountId" : "1022288858",
      "userLink" : "https://twitter.com/intent/user?user_id=1022288858"
    }
  },
  {
    "following" : {
      "accountId" : "1508528078854795271",
      "userLink" : "https://twitter.com/intent/user?user_id=1508528078854795271"
    }
  },
  {
    "following" : {
      "accountId" : "4205182294",
      "userLink" : "https://twitter.com/intent/user?user_id=4205182294"
    }
  },
  {
    "following" : {
      "accountId" : "1450252824",
      "userLink" : "https://twitter.com/intent/user?user_id=1450252824"
    }
  },
  {
    "following" : {
      "accountId" : "18309778",
      "userLink" : "https://twitter.com/intent/user?user_id=18309778"
    }
  },
  {
    "following" : {
      "accountId" : "990471215079768064",
      "userLink" : "https://twitter.com/intent/user?user_id=990471215079768064"
    }
  },
  {
    "following" : {
      "accountId" : "1966964984",
      "userLink" : "https://twitter.com/intent/user?user_id=1966964984"
    }
  },
  {
    "following" : {
      "accountId" : "1083152191",
      "userLink" : "https://twitter.com/intent/user?user_id=1083152191"
    }
  },
  {
    "following" : {
      "accountId" : "971823505267462144",
      "userLink" : "https://twitter.com/intent/user?user_id=971823505267462144"
    }
  },
  {
    "following" : {
      "accountId" : "925761414601551872",
      "userLink" : "https://twitter.com/intent/user?user_id=925761414601551872"
    }
  },
  {
    "following" : {
      "accountId" : "1550658066",
      "userLink" : "https://twitter.com/intent/user?user_id=1550658066"
    }
  },
  {
    "following" : {
      "accountId" : "466686068",
      "userLink" : "https://twitter.com/intent/user?user_id=466686068"
    }
  },
  {
    "following" : {
      "accountId" : "2577721015",
      "userLink" : "https://twitter.com/intent/user?user_id=2577721015"
    }
  },
  {
    "following" : {
      "accountId" : "109009155",
      "userLink" : "https://twitter.com/intent/user?user_id=109009155"
    }
  },
  {
    "following" : {
      "accountId" : "126460660",
      "userLink" : "https://twitter.com/intent/user?user_id=126460660"
    }
  },
  {
    "following" : {
      "accountId" : "365956744",
      "userLink" : "https://twitter.com/intent/user?user_id=365956744"
    }
  },
  {
    "following" : {
      "accountId" : "2321975708",
      "userLink" : "https://twitter.com/intent/user?user_id=2321975708"
    }
  },
  {
    "following" : {
      "accountId" : "3978799274",
      "userLink" : "https://twitter.com/intent/user?user_id=3978799274"
    }
  },
  {
    "following" : {
      "accountId" : "1722265146",
      "userLink" : "https://twitter.com/intent/user?user_id=1722265146"
    }
  },
  {
    "following" : {
      "accountId" : "3545867712",
      "userLink" : "https://twitter.com/intent/user?user_id=3545867712"
    }
  },
  {
    "following" : {
      "accountId" : "624188337",
      "userLink" : "https://twitter.com/intent/user?user_id=624188337"
    }
  },
  {
    "following" : {
      "accountId" : "1300598688",
      "userLink" : "https://twitter.com/intent/user?user_id=1300598688"
    }
  },
  {
    "following" : {
      "accountId" : "368272402",
      "userLink" : "https://twitter.com/intent/user?user_id=368272402"
    }
  },
  {
    "following" : {
      "accountId" : "14649689",
      "userLink" : "https://twitter.com/intent/user?user_id=14649689"
    }
  },
  {
    "following" : {
      "accountId" : "364420117",
      "userLink" : "https://twitter.com/intent/user?user_id=364420117"
    }
  }
]