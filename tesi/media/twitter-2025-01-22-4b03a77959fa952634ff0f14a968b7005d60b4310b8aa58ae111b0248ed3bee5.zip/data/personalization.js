window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "Italian",
            "isDisabled" : false
          },
          {
            "language" : "art (Private-Use: emoji)",
            "isDisabled" : false
          },
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "No linguistic content",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "2D animation",
            "isDisabled" : false
          },
          {
            "name" : "3D printing",
            "isDisabled" : false
          },
          {
            "name" : "Ace Attorney",
            "isDisabled" : false
          },
          {
            "name" : "Action & adventure films",
            "isDisabled" : false
          },
          {
            "name" : "Adult Swim",
            "isDisabled" : false
          },
          {
            "name" : "Adult animation",
            "isDisabled" : false
          },
          {
            "name" : "Adventure Time",
            "isDisabled" : false
          },
          {
            "name" : "Amazon",
            "isDisabled" : false
          },
          {
            "name" : "Amazon - Alexa",
            "isDisabled" : false
          },
          {
            "name" : "American Heart Association",
            "isDisabled" : false
          },
          {
            "name" : "Angela Merkel",
            "isDisabled" : false
          },
          {
            "name" : "Animal Crossing",
            "isDisabled" : false
          },
          {
            "name" : "Animaniacs",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Animation directors, producers, & writers",
            "isDisabled" : false
          },
          {
            "name" : "Animation software",
            "isDisabled" : false
          },
          {
            "name" : "Anime",
            "isDisabled" : false
          },
          {
            "name" : "Arcade gaming",
            "isDisabled" : false
          },
          {
            "name" : "Arduino",
            "isDisabled" : false
          },
          {
            "name" : "Arts & Culture",
            "isDisabled" : false
          },
          {
            "name" : "Arts & culture",
            "isDisabled" : false
          },
          {
            "name" : "Atalanta BC",
            "isDisabled" : false
          },
          {
            "name" : "Bayonetta",
            "isDisabled" : false
          },
          {
            "name" : "Ben Affleck",
            "isDisabled" : false
          },
          {
            "name" : "Bethesda",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Bloodborne",
            "isDisabled" : false
          },
          {
            "name" : "Cartoon Network",
            "isDisabled" : false
          },
          {
            "name" : "Cartoons",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "Character design",
            "isDisabled" : false
          },
          {
            "name" : "Civil Society",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comics",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Computer networking",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Computer reviews",
            "isDisabled" : false
          },
          {
            "name" : "Concept art",
            "isDisabled" : false
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Cookie Run",
            "isDisabled" : false
          },
          {
            "name" : "Cosplay",
            "isDisabled" : false
          },
          {
            "name" : "DOOM",
            "isDisabled" : false
          },
          {
            "name" : "Dance",
            "isDisabled" : false
          },
          {
            "name" : "Daredevil",
            "isDisabled" : false
          },
          {
            "name" : "Dark Souls",
            "isDisabled" : false
          },
          {
            "name" : "Darth Vader",
            "isDisabled" : false
          },
          {
            "name" : "Death Stranding",
            "isDisabled" : false
          },
          {
            "name" : "Deathloop",
            "isDisabled" : false
          },
          {
            "name" : "Dell",
            "isDisabled" : false
          },
          {
            "name" : "Detroit: Become Human",
            "isDisabled" : false
          },
          {
            "name" : "Devil May Cry",
            "isDisabled" : false
          },
          {
            "name" : "Discord",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Donald Trump",
            "isDisabled" : false
          },
          {
            "name" : "Drama films",
            "isDisabled" : false
          },
          {
            "name" : "Drawing & illustration",
            "isDisabled" : false
          },
          {
            "name" : "Drawing and sketching",
            "isDisabled" : false
          },
          {
            "name" : "Dropbox",
            "isDisabled" : false
          },
          {
            "name" : "Dungeons & Dragons",
            "isDisabled" : false
          },
          {
            "name" : "ESA",
            "isDisabled" : false
          },
          {
            "name" : "Echo Fox",
            "isDisabled" : false
          },
          {
            "name" : "Elden Ring",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment awards",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Europe - Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Fallout",
            "isDisabled" : false
          },
          {
            "name" : "Financial Times",
            "isDisabled" : false
          },
          {
            "name" : "Five Nights at Freddy's",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "Froot Loops",
            "isDisabled" : false
          },
          {
            "name" : "Futurama",
            "isDisabled" : false
          },
          {
            "name" : "Game development",
            "isDisabled" : false
          },
          {
            "name" : "Game emulation",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gaming news",
            "isDisabled" : false
          },
          {
            "name" : "Gaming news and general info",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "God of War",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Gorillaz",
            "isDisabled" : false
          },
          {
            "name" : "Gravity Falls",
            "isDisabled" : false
          },
          {
            "name" : "Hades",
            "isDisabled" : false
          },
          {
            "name" : "Half-Life",
            "isDisabled" : false
          },
          {
            "name" : "Halo",
            "isDisabled" : false
          },
          {
            "name" : "Harvey Weinstein",
            "isDisabled" : false
          },
          {
            "name" : "Harvey Weinstein Scandal",
            "isDisabled" : false
          },
          {
            "name" : "Hazbin Hotel",
            "isDisabled" : false
          },
          {
            "name" : "Heath Ledger",
            "isDisabled" : false
          },
          {
            "name" : "Helluva Boss",
            "isDisabled" : false
          },
          {
            "name" : "Hideo Kojima",
            "isDisabled" : false
          },
          {
            "name" : "Hollywood Sex Scandal",
            "isDisabled" : false
          },
          {
            "name" : "Homestuck",
            "isDisabled" : false
          },
          {
            "name" : "Immigration Policies Worldwide",
            "isDisabled" : false
          },
          {
            "name" : "Indie games",
            "isDisabled" : false
          },
          {
            "name" : "Infinity Train",
            "isDisabled" : false
          },
          {
            "name" : "International Clubs - Soccer",
            "isDisabled" : false
          },
          {
            "name" : "International Space Station",
            "isDisabled" : false
          },
          {
            "name" : "Italy - Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Jared Leto",
            "isDisabled" : false
          },
          {
            "name" : "Joaquin Phoenix",
            "isDisabled" : false
          },
          {
            "name" : "Joker (2019)",
            "isDisabled" : false
          },
          {
            "name" : "Juniper Networks",
            "isDisabled" : false
          },
          {
            "name" : "Kevin Mirallas",
            "isDisabled" : false
          },
          {
            "name" : "Kingdom Hearts",
            "isDisabled" : false
          },
          {
            "name" : "Markiplier",
            "isDisabled" : false
          },
          {
            "name" : "Martin Scorsese",
            "isDisabled" : false
          },
          {
            "name" : "Marvel Universe",
            "isDisabled" : false
          },
          {
            "name" : "Marvel's Avengers",
            "isDisabled" : false
          },
          {
            "name" : "Matteo Salvini",
            "isDisabled" : false
          },
          {
            "name" : "Metal Gear",
            "isDisabled" : false
          },
          {
            "name" : "Metal Slug",
            "isDisabled" : false
          },
          {
            "name" : "Metroid",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Windows",
            "isDisabled" : false
          },
          {
            "name" : "Minecraft",
            "isDisabled" : false
          },
          {
            "name" : "Music festivals and concerts",
            "isDisabled" : false
          },
          {
            "name" : "Music news and general info",
            "isDisabled" : false
          },
          {
            "name" : "My Little Pony",
            "isDisabled" : false
          },
          {
            "name" : "Myth",
            "isDisabled" : false
          },
          {
            "name" : "Neon Genesis Evangelion",
            "isDisabled" : false
          },
          {
            "name" : "Netflix",
            "isDisabled" : false
          },
          {
            "name" : "Nickelodeon All-Star Brawl",
            "isDisabled" : false
          },
          {
            "name" : "Nintendo 3DS",
            "isDisabled" : false
          },
          {
            "name" : "Nintendo Switch",
            "isDisabled" : false
          },
          {
            "name" : "No Man's Sky",
            "isDisabled" : false
          },
          {
            "name" : "One Punch Man",
            "isDisabled" : false
          },
          {
            "name" : "Online gaming",
            "isDisabled" : false
          },
          {
            "name" : "Other",
            "isDisabled" : false
          },
          {
            "name" : "Our Flag Means Death",
            "isDisabled" : false
          },
          {
            "name" : "Over the Garden Wall",
            "isDisabled" : false
          },
          {
            "name" : "Overwatch",
            "isDisabled" : false
          },
          {
            "name" : "PC gaming",
            "isDisabled" : false
          },
          {
            "name" : "Philanthropy",
            "isDisabled" : false
          },
          {
            "name" : "Photography",
            "isDisabled" : false
          },
          {
            "name" : "Piano",
            "isDisabled" : false
          },
          {
            "name" : "Piratenpartei",
            "isDisabled" : false
          },
          {
            "name" : "Pizza",
            "isDisabled" : false
          },
          {
            "name" : "PlayStation",
            "isDisabled" : false
          },
          {
            "name" : "PlayStation Vita",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Rahm Emanuel",
            "isDisabled" : false
          },
          {
            "name" : "Retro gaming",
            "isDisabled" : false
          },
          {
            "name" : "Rick and Morty",
            "isDisabled" : false
          },
          {
            "name" : "Ricky Gervais",
            "isDisabled" : false
          },
          {
            "name" : "Robert Downey Jr",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi and fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Secret of Mana",
            "isDisabled" : false
          },
          {
            "name" : "Sekiro: Shadows Die Twice",
            "isDisabled" : false
          },
          {
            "name" : "Sergio Mattarella",
            "isDisabled" : false
          },
          {
            "name" : "Serie A",
            "isDisabled" : false
          },
          {
            "name" : "Silent Hill",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Sonic Mania",
            "isDisabled" : false
          },
          {
            "name" : "Sonic the Hedgehog",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Splatoon",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sporting goods",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Spyro the Dragon",
            "isDisabled" : false
          },
          {
            "name" : "Star Wars Resistance",
            "isDisabled" : false
          },
          {
            "name" : "Stardew Valley",
            "isDisabled" : false
          },
          {
            "name" : "Steam Deck",
            "isDisabled" : false
          },
          {
            "name" : "Steven Universe",
            "isDisabled" : false
          },
          {
            "name" : "Storyboarding",
            "isDisabled" : false
          },
          {
            "name" : "Streets of Rage",
            "isDisabled" : false
          },
          {
            "name" : "Super Mario",
            "isDisabled" : false
          },
          {
            "name" : "Super Mario Odyssey",
            "isDisabled" : false
          },
          {
            "name" : "Tech industry",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Teenage Mutant Ninja Turtles",
            "isDisabled" : false
          },
          {
            "name" : "The Elder Scrolls",
            "isDisabled" : false
          },
          {
            "name" : "The Last of Us",
            "isDisabled" : false
          },
          {
            "name" : "The Legend of Zelda",
            "isDisabled" : false
          },
          {
            "name" : "The Owl House",
            "isDisabled" : false
          },
          {
            "name" : "The Powerpuff Girls",
            "isDisabled" : false
          },
          {
            "name" : "The Witcher",
            "isDisabled" : false
          },
          {
            "name" : "Titanfall",
            "isDisabled" : false
          },
          {
            "name" : "Tom Hiddleston",
            "isDisabled" : false
          },
          {
            "name" : "Undertale",
            "isDisabled" : false
          },
          {
            "name" : "Valve Corporation",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Weddings",
            "isDisabled" : false
          },
          {
            "name" : "Xbox",
            "isDisabled" : false
          },
          {
            "name" : "Yakuza",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "scarra",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "Daredevil",
          "Daredevil (Netflix)",
          "Metal Gear Solid V"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]