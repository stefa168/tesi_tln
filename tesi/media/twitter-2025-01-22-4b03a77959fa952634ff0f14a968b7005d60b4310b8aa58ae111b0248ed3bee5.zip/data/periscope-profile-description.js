window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "🐶🐭"
    }
  }
]