window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "360730908",
      "emailChange" : {
        "changedAt" : "2011-08-24T14:44:47.000Z",
        "changedTo" : "stefa168@hotmail.it"
      }
    }
  }
]