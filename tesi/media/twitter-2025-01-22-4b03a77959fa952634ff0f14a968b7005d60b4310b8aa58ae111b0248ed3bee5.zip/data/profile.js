window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "🐶🐭",
        "website" : "",
        "location" : "Asti, Piemonte"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/988178957315997696/lWTTlWKI.jpg"
    }
  }
]