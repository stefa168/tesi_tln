window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Stefano Vittorio Porta",
      "digitsId" : "",
      "username" : "stefa168",
      "twitterId" : "360730908",
      "id" : "1lZKpZGOyRnEn",
      "twitterScreenName" : "stefa168",
      "isTwitterUser" : true,
      "createdAt" : "2021-03-27T02:21:41.673591033Z"
    }
  }
]