window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "phoneNumber" : "+393662846410",
        "carrier" : "vodafone_it",
        "deviceType" : "Auth",
        "updatedDate" : "2021.09.29",
        "createdDate" : "2015.03.27"
      }
    }
  }
]