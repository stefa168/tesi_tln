window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "stefa168@hotmail.it",
      "createdVia" : "web",
      "username" : "stefa168",
      "accountId" : "360730908",
      "createdAt" : "2011-08-23T17:37:15.000Z",
      "accountDisplayName" : "Stefano Vittorio Porta"
    }
  }
]