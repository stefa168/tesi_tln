window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "360730908"
    }
  }
]