window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1874094477033562328",
      "fullText" : "Happy new year.🎆🎆🎆\nThis year felt extremely short, especially since Ive met alot of new people.\n\nHere's a rough compilation of all the artists / characters I enjoyed this year.\n\nThis took a while so I hope the ones here can appreciate it.\n\n(next year if I missed anyone) https://t.co/vgEQlPWMWb",
      "expandedUrl" : "https://twitter.com/i/web/status/1874094477033562328"
    }
  },
  {
    "like" : {
      "tweetId" : "1818097211948896365",
      "fullText" : "Lets all take a moment out of our day to watch a long standing member of the @Voron_Design Team, @Timmit99 failing to catch a baseball on national TV https://t.co/XTba1m3yKr",
      "expandedUrl" : "https://twitter.com/i/web/status/1818097211948896365"
    }
  },
  {
    "like" : {
      "tweetId" : "1845109912231145785",
      "fullText" : "() is an empty tuple\nnot makes it True\nstr turns it into \"True\"\nmin of a string returns first char, here it's T\nT is 84 in unicode, ord turns it into that\nrange(84) is an exclusive range, which is [0, 84)\nsumming up all those numbers gives you 3486\n3486 in unicode is ඞ\namogus https://t.co/nTSQOlMDy6",
      "expandedUrl" : "https://twitter.com/i/web/status/1845109912231145785"
    }
  },
  {
    "like" : {
      "tweetId" : "1845281417179041853",
      "fullText" : "#魔法少女にあこがれて https://t.co/Pm2BpHV1fM",
      "expandedUrl" : "https://twitter.com/i/web/status/1845281417179041853"
    }
  },
  {
    "like" : {
      "tweetId" : "1834155812073439234",
      "fullText" : "分割前とお気に入りのところです https://t.co/HqtSb2AAj8 https://t.co/knyXzPGd3o",
      "expandedUrl" : "https://twitter.com/i/web/status/1834155812073439234"
    }
  },
  {
    "like" : {
      "tweetId" : "1834770038936805864",
      "fullText" : "マジアアズール💙　#まほあこ https://t.co/HJCpMeZCiA",
      "expandedUrl" : "https://twitter.com/i/web/status/1834770038936805864"
    }
  },
  {
    "like" : {
      "tweetId" : "1834852778021470251",
      "fullText" : "#まほあこ https://t.co/RqdSfnUw25",
      "expandedUrl" : "https://twitter.com/i/web/status/1834852778021470251"
    }
  },
  {
    "like" : {
      "tweetId" : "1834876544231391693",
      "fullText" : "#魔法少女にあこがれて #柊うてな #阿良河キウィ https://t.co/6o41gvJEx9",
      "expandedUrl" : "https://twitter.com/i/web/status/1834876544231391693"
    }
  },
  {
    "like" : {
      "tweetId" : "1834972413509222902",
      "fullText" : "#まほあこ 🐱🐱 https://t.co/z2g98MKVaw",
      "expandedUrl" : "https://twitter.com/i/web/status/1834972413509222902"
    }
  },
  {
    "like" : {
      "tweetId" : "1834961755745010036",
      "fullText" : "苦労人すぎて好き\n#まほあこ https://t.co/G5YIwhHRfg",
      "expandedUrl" : "https://twitter.com/i/web/status/1834961755745010036"
    }
  },
  {
    "like" : {
      "tweetId" : "1834947312566911301",
      "fullText" : "鬼龍院 皐月 https://t.co/LoD7Lspuq1",
      "expandedUrl" : "https://twitter.com/i/web/status/1834947312566911301"
    }
  },
  {
    "like" : {
      "tweetId" : "1835036439199060418",
      "fullText" : "https://t.co/rrkJheb3Ig",
      "expandedUrl" : "https://twitter.com/i/web/status/1835036439199060418"
    }
  },
  {
    "like" : {
      "tweetId" : "1835182585120800957",
      "fullText" : "#まほあこ\nロコムジカ https://t.co/YOWwInAF27",
      "expandedUrl" : "https://twitter.com/i/web/status/1835182585120800957"
    }
  },
  {
    "like" : {
      "tweetId" : "1835326037372350517",
      "fullText" : "https://t.co/jmxBTrZJKf",
      "expandedUrl" : "https://twitter.com/i/web/status/1835326037372350517"
    }
  },
  {
    "like" : {
      "tweetId" : "1835363345773592647",
      "fullText" : "젖가슴의마귀가\n젖가슴으로민간인을홀린다…\n요망한것……………. https://t.co/J4q1AUPelp",
      "expandedUrl" : "https://twitter.com/i/web/status/1835363345773592647"
    }
  },
  {
    "like" : {
      "tweetId" : "1835417479549538721",
      "fullText" : "#mahoako #魔法少女にあこがれて #まほあこ #GushingoverMagicalGirls https://t.co/p4quzo65T1",
      "expandedUrl" : "https://twitter.com/i/web/status/1835417479549538721"
    }
  },
  {
    "like" : {
      "tweetId" : "1835435961364464113",
      "fullText" : "终于画完了。我要把这张图印在衣服上面穿着。#まほあこ https://t.co/ilfTWWPOsj",
      "expandedUrl" : "https://twitter.com/i/web/status/1835435961364464113"
    }
  },
  {
    "like" : {
      "tweetId" : "1835540708339413017",
      "fullText" : "PV包帯さやかちゃんいた!!ので再掲\n#ワルプルギスの廻天 https://t.co/SVAWAPEHFd",
      "expandedUrl" : "https://twitter.com/i/web/status/1835540708339413017"
    }
  },
  {
    "like" : {
      "tweetId" : "1835561548535992827",
      "fullText" : "まほあこ\nベーゼちゃんにスクランダー装着させればいけるのか？ https://t.co/QUG53oygPS",
      "expandedUrl" : "https://twitter.com/i/web/status/1835561548535992827"
    }
  },
  {
    "like" : {
      "tweetId" : "1835680995590455470",
      "fullText" : "包帯さやかちゃん🤕 https://t.co/2jYbsvLood",
      "expandedUrl" : "https://twitter.com/i/web/status/1835680995590455470"
    }
  },
  {
    "like" : {
      "tweetId" : "1835383344080753126",
      "fullText" : "스엠님 이런거 볼때마다 그리고싶어져요 https://t.co/XoTUSv6bPY https://t.co/ZFT0ECqOmD",
      "expandedUrl" : "https://twitter.com/i/web/status/1835383344080753126"
    }
  },
  {
    "like" : {
      "tweetId" : "1835377965192147099",
      "fullText" : "this is my proudest creation. https://t.co/5YrGQh3NYT",
      "expandedUrl" : "https://twitter.com/i/web/status/1835377965192147099"
    }
  },
  {
    "like" : {
      "tweetId" : "1835786990207508741",
      "fullText" : "鬼畜ベーゼ🌀🌀🌀\n\n#まほあこ\n#魔法少女にあこがれて https://t.co/oKOcWlkdKI",
      "expandedUrl" : "https://twitter.com/i/web/status/1835786990207508741"
    }
  },
  {
    "like" : {
      "tweetId" : "1836030452261626007",
      "fullText" : "#まほあこ https://t.co/dfklchM55s",
      "expandedUrl" : "https://twitter.com/i/web/status/1836030452261626007"
    }
  },
  {
    "like" : {
      "tweetId" : "1835769743581782225",
      "fullText" : "소꿉친구가 마법소녀AU 아이돌AU 다 해줌  #まほあこ https://t.co/9NuV81KaX2",
      "expandedUrl" : "https://twitter.com/i/web/status/1835769743581782225"
    }
  },
  {
    "like" : {
      "tweetId" : "1835514233708245250",
      "fullText" : "Commissioned Artist：小菊8、76彼    X：@ 0_71_Rain\n\nOnce again, I'd like to remind everyone that if you'd like to support me in continuing to create yuri doujinshi, you can purchase my doujinshi e-books on Booth and Patreon. \nYou can also buy physical copies of the books on… https://t.co/jcQHfXGNwl",
      "expandedUrl" : "https://twitter.com/i/web/status/1835514233708245250"
    }
  },
  {
    "like" : {
      "tweetId" : "1835553267012849828",
      "fullText" : "회천에서의 이 파란여자가 너무 좋습니다 https://t.co/Ez2js6O2cy",
      "expandedUrl" : "https://twitter.com/i/web/status/1835553267012849828"
    }
  },
  {
    "like" : {
      "tweetId" : "1835515356905087046",
      "fullText" : "#まほあこ https://t.co/JUGaIl0ioX",
      "expandedUrl" : "https://twitter.com/i/web/status/1835515356905087046"
    }
  },
  {
    "like" : {
      "tweetId" : "1835566945430602225",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1835566945430602225"
    }
  },
  {
    "like" : {
      "tweetId" : "1828499186209243490",
      "fullText" : "midwest miku https://t.co/PG3udPHd8g",
      "expandedUrl" : "https://twitter.com/i/web/status/1828499186209243490"
    }
  },
  {
    "like" : {
      "tweetId" : "1832470706401017911",
      "fullText" : "@Slime_Cursive here ya go! https://t.co/cQqoiaTfSg",
      "expandedUrl" : "https://twitter.com/i/web/status/1832470706401017911"
    }
  },
  {
    "like" : {
      "tweetId" : "1831303341344764045",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1831303341344764045"
    }
  },
  {
    "like" : {
      "tweetId" : "1832116454784954435",
      "fullText" : "??? https://t.co/Kjj8GC17c0 https://t.co/xaQ74FNuds",
      "expandedUrl" : "https://twitter.com/i/web/status/1832116454784954435"
    }
  },
  {
    "like" : {
      "tweetId" : "1826684396025598406",
      "fullText" : "🐶😋#まほあこSM大感謝祭 https://t.co/iyXxvQXi1G",
      "expandedUrl" : "https://twitter.com/i/web/status/1826684396025598406"
    }
  },
  {
    "like" : {
      "tweetId" : "1827038441026285745",
      "fullText" : "委屈摩 https://t.co/wecgZJsOsv https://t.co/wIeOnWXhP7",
      "expandedUrl" : "https://twitter.com/i/web/status/1827038441026285745"
    }
  },
  {
    "like" : {
      "tweetId" : "1827324505527873636",
      "fullText" : "アクキーこれでいくかあ🐉 https://t.co/zxEwV4uXre",
      "expandedUrl" : "https://twitter.com/i/web/status/1827324505527873636"
    }
  },
  {
    "like" : {
      "tweetId" : "1827408519274119482",
      "fullText" : "I want this to be a room that \" shrinks until honest with each other''＞:3\n#まほあこ https://t.co/uCPQHh2Dlp",
      "expandedUrl" : "https://twitter.com/i/web/status/1827408519274119482"
    }
  },
  {
    "like" : {
      "tweetId" : "1827262373163626894",
      "fullText" : "#魔法少女にあこがれて #まほあこ #GushingoverMagicalGirls #mahoako  \n依賴繪     \nイラスト/Commissioned Artist：修來 https://t.co/bB4PCmpq77",
      "expandedUrl" : "https://twitter.com/i/web/status/1827262373163626894"
    }
  },
  {
    "like" : {
      "tweetId" : "1827393102501572730",
      "fullText" : "【wip/予告情報】\n8/25　12:15公開予定\n\n私から言えることは……\n「私の中の最高傑作」 https://t.co/jd8gsJGZ5R",
      "expandedUrl" : "https://twitter.com/i/web/status/1827393102501572730"
    }
  },
  {
    "like" : {
      "tweetId" : "1815890257444810861",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1815890257444810861"
    }
  },
  {
    "like" : {
      "tweetId" : "1817405097556533512",
      "fullText" : "Ok, I had an idea\n.\n.\n.\n#魔法少女にあこがれて #mahoushoujo #MahouShoujoniAkogarete #まほあこ #GushingoverMagicalGirls #mahoako #柊うてな #マジアベーゼ #杜乃こりす #ネロアリス https://t.co/8TpsXWmL1J",
      "expandedUrl" : "https://twitter.com/i/web/status/1817405097556533512"
    }
  },
  {
    "like" : {
      "tweetId" : "1821184893315117278",
      "fullText" : "미나카미네 엄마,\n제가 대신 망상해드렸습니다. https://t.co/rK8chUDy7A",
      "expandedUrl" : "https://twitter.com/i/web/status/1821184893315117278"
    }
  },
  {
    "like" : {
      "tweetId" : "1822118426430537814",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1822118426430537814"
    }
  },
  {
    "like" : {
      "tweetId" : "1822236128478412817",
      "fullText" : "#魔法少女にあこがれて \n#まほあこ https://t.co/n5gX7rhErw",
      "expandedUrl" : "https://twitter.com/i/web/status/1822236128478412817"
    }
  },
  {
    "like" : {
      "tweetId" : "1823112944487415844",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1823112944487415844"
    }
  },
  {
    "like" : {
      "tweetId" : "1820139343677374807",
      "fullText" : "more🐱#まほあこ https://t.co/K04a0pTiFL",
      "expandedUrl" : "https://twitter.com/i/web/status/1820139343677374807"
    }
  },
  {
    "like" : {
      "tweetId" : "1826843647003799997",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1826843647003799997"
    }
  },
  {
    "like" : {
      "tweetId" : "1822964572917309450",
      "fullText" : "#よふかしのうた\n📸 https://t.co/W8iIfph5Lv",
      "expandedUrl" : "https://twitter.com/i/web/status/1822964572917309450"
    }
  },
  {
    "like" : {
      "tweetId" : "1803036050618806554",
      "fullText" : "Nazuna &amp; Nazuna \n#よふかしのうた https://t.co/8agjYqQvo2",
      "expandedUrl" : "https://twitter.com/i/web/status/1803036050618806554"
    }
  },
  {
    "like" : {
      "tweetId" : "1816089552249053634",
      "fullText" : "Nazuna ♨️ \n#よふかしのうた https://t.co/ihJgR7wIoj",
      "expandedUrl" : "https://twitter.com/i/web/status/1816089552249053634"
    }
  },
  {
    "like" : {
      "tweetId" : "1503327421839417344",
      "fullText" : "I hereby challenge\nВладимир Путин \nto single combat\n\nStakes are Україна",
      "expandedUrl" : "https://twitter.com/i/web/status/1503327421839417344"
    }
  },
  {
    "like" : {
      "tweetId" : "1491467468996431873",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1491467468996431873"
    }
  },
  {
    "like" : {
      "tweetId" : "1471914055392710663",
      "fullText" : "https://t.co/RJESmQ5LY3",
      "expandedUrl" : "https://twitter.com/i/web/status/1471914055392710663"
    }
  },
  {
    "like" : {
      "tweetId" : "1203420033101156353",
      "fullText" : "from: noreply@discordapp.com\nsubject: Regarding The Recent Controversy\n\nohai ~ o^o ~✨ you may have heard 🗣️ that we are funneling money 🌪️💵 into defense contracting for overseas drone strikes ✈️💣❌ now THAT'S top decking lethal! \n\nclick wumpus 👇🦛 for the REAL story 📰",
      "expandedUrl" : "https://twitter.com/i/web/status/1203420033101156353"
    }
  },
  {
    "like" : {
      "tweetId" : "1465626003846283274",
      "fullText" : "📣Which version do you prefer? \n❤️for SKR PICO V1.0\n🔁for SKR PICO V1.0 (ARMORED)\n\n#bigtreetech #biqu #3dprinter #3dprinting #3dprinted #3dprinterpart #motherboard #skrpico #corexy #rasperrybi https://t.co/lFQKlSpQrM",
      "expandedUrl" : "https://twitter.com/i/web/status/1465626003846283274"
    }
  },
  {
    "like" : {
      "tweetId" : "1460828816285130754",
      "expandedUrl" : "https://twitter.com/i/web/status/1460828816285130754"
    }
  },
  {
    "like" : {
      "tweetId" : "1460810803523817474",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1460810803523817474"
    }
  },
  {
    "like" : {
      "tweetId" : "1449319992504332289",
      "fullText" : "Liftoff! United Launch Alliance’s Atlas V rocket launches NASA’s Lucy mission from Cape Canaveral, Florida at 5:34am this morning.\n\nLucy begins its 12-year journey to study the Trojan asteroids!\n\n📷: Me for @SuperclusterHQ https://t.co/Nl5sxYnP6g",
      "expandedUrl" : "https://twitter.com/i/web/status/1449319992504332289"
    }
  },
  {
    "like" : {
      "tweetId" : "1449064915931648008",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1449064915931648008"
    }
  },
  {
    "like" : {
      "tweetId" : "1445089349826224131",
      "fullText" : "@kevincollier Accidental suicide - killing off its own network with a faulty routing update, to the point admins can't put everything back the way it was. They may well be down for a good long while.\n\nFirst two comments have been deleted https://t.co/isSMVZhPQ1",
      "expandedUrl" : "https://twitter.com/i/web/status/1445089349826224131"
    }
  },
  {
    "like" : {
      "tweetId" : "1445086376798662658",
      "fullText" : "@SassafrasYote There are *a lot* of users joining today from other platforms that are down. The wizards are working their strange server magicks to try and keep things up but it may be a bit slow. Sorry!",
      "expandedUrl" : "https://twitter.com/i/web/status/1445086376798662658"
    }
  },
  {
    "like" : {
      "tweetId" : "1418237606991589379",
      "fullText" : "Puny Gods 🐍💚✨\n#Loki #Sylvie #KidLoki #ClassicLoki #AlligatorLoki #mobius https://t.co/ElfYdgxF5v",
      "expandedUrl" : "https://twitter.com/i/web/status/1418237606991589379"
    }
  },
  {
    "like" : {
      "tweetId" : "1091536402255413248",
      "fullText" : "I’ve been looking for this video for YEARS. https://t.co/KsxXh2YrpM",
      "expandedUrl" : "https://twitter.com/i/web/status/1091536402255413248"
    }
  },
  {
    "like" : {
      "tweetId" : "1402753711907168265",
      "fullText" : "bogos binted? https://t.co/1yB7Ux0qMM",
      "expandedUrl" : "https://twitter.com/i/web/status/1402753711907168265"
    }
  },
  {
    "like" : {
      "tweetId" : "1422173130534047751",
      "fullText" : "Non ho mai letto così tante puttanate sulla stampa nazionale come nelle ultime 24 ore.",
      "expandedUrl" : "https://twitter.com/i/web/status/1422173130534047751"
    }
  },
  {
    "like" : {
      "tweetId" : "1422124969660661761",
      "fullText" : "@raistolo @RegioneLazio, @nzingaretti  per vostra info. Delle due l'una: o non capite niente di informatica, oppure la vostra è una scusa per coprire le mancanze di un sistema sicuro che gestice dati dei cittadini.",
      "expandedUrl" : "https://twitter.com/i/web/status/1422124969660661761"
    }
  },
  {
    "like" : {
      "tweetId" : "1422120545932517378",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1422120545932517378"
    }
  },
  {
    "like" : {
      "tweetId" : "1422112713854029824",
      "fullText" : "2) C'è un solo motivo per CIFRARE i dati con un RANSOMware, ed è spiegato nel nome: chiedere un riscatto. Se uno vuole fare un danno e basta, non ha motivi per CIFRARE, si limita a PIALLARE tutto il piallabile. Quindi, la teoria \"sono stati i no vax\" è davvero poco credibile.",
      "expandedUrl" : "https://twitter.com/i/web/status/1422112713854029824"
    }
  },
  {
    "like" : {
      "tweetId" : "1422112711354241027",
      "fullText" : "Leggo commenti più o meno deliranti sul \"potente attacco\" informatico ai sistemi della regione Lazio. Sorvolando sul fatto che nessuno competente in materia direbbe mai \"potente attacco\", e che i computer non vanno \"in tilt\" perché non sono flipper, qualche considerazione sparsa:",
      "expandedUrl" : "https://twitter.com/i/web/status/1422112711354241027"
    }
  },
  {
    "like" : {
      "tweetId" : "1421189933172146178",
      "fullText" : "Channels deleted... \n\nGreat way to end a holiday tbh https://t.co/i22FXDCay6",
      "expandedUrl" : "https://twitter.com/i/web/status/1421189933172146178"
    }
  },
  {
    "like" : {
      "tweetId" : "1421192048040947713",
      "fullText" : "Heads up not YouTube's fault it's my own for falling for a very nice scam \n\nYouTube friends fixing it atm but until then I am going to be shaking and crying like an anxious sausage",
      "expandedUrl" : "https://twitter.com/i/web/status/1421192048040947713"
    }
  },
  {
    "like" : {
      "tweetId" : "1419640700262563846",
      "fullText" : "La prossima volta che sentite chiacchierare di sofisticatissime policy e prodotti di security, potete commentare con questo video: https://t.co/ny9L0xGTCr",
      "expandedUrl" : "https://twitter.com/i/web/status/1419640700262563846"
    }
  },
  {
    "like" : {
      "tweetId" : "1405225248056823809",
      "fullText" : "Megaman Model DR (Dread)\n\n#MetroidDread x #Megaman crossover. https://t.co/z74emNT2IY",
      "expandedUrl" : "https://twitter.com/i/web/status/1405225248056823809"
    }
  },
  {
    "like" : {
      "tweetId" : "1414652643608186880",
      "fullText" : "Curious, who wears it the best? Mega, Roll or Proto? #MetroidDread #Megaman https://t.co/cW0eU0NkS6",
      "expandedUrl" : "https://twitter.com/i/web/status/1414652643608186880"
    }
  },
  {
    "like" : {
      "tweetId" : "894600950941220864",
      "fullText" : "dimmadone with all the haterz #dimmadab https://t.co/5qFhBR1aky",
      "expandedUrl" : "https://twitter.com/i/web/status/894600950941220864"
    }
  },
  {
    "like" : {
      "tweetId" : "1409482881701924866",
      "fullText" : "Life’s hard as a duckling when mum keeps disappearing every 5 seconds. https://t.co/FEsLV1KXni",
      "expandedUrl" : "https://twitter.com/i/web/status/1409482881701924866"
    }
  },
  {
    "like" : {
      "tweetId" : "1405657003838509058",
      "fullText" : "https://t.co/IR0VKutXz0",
      "expandedUrl" : "https://twitter.com/i/web/status/1405657003838509058"
    }
  },
  {
    "like" : {
      "tweetId" : "1405746945373532171",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1405746945373532171"
    }
  },
  {
    "like" : {
      "tweetId" : "1405523685163687945",
      "fullText" : "Metroid Dread's 60 dollar price tag being questioned in a space where people spend hundreds of dollars on skins gets me every time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1405523685163687945"
    }
  },
  {
    "like" : {
      "tweetId" : "1403665842357903360",
      "fullText" : "this is real https://t.co/2qsytxb71s",
      "expandedUrl" : "https://twitter.com/i/web/status/1403665842357903360"
    }
  },
  {
    "like" : {
      "tweetId" : "1401862746686341120",
      "fullText" : "verified",
      "expandedUrl" : "https://twitter.com/i/web/status/1401862746686341120"
    }
  },
  {
    "like" : {
      "tweetId" : "1400573093433774085",
      "fullText" : "@NintendoAmerica https://t.co/yJM49l3RdJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1400573093433774085"
    }
  },
  {
    "like" : {
      "tweetId" : "1397915454744633356",
      "fullText" : "drop the pro you cowards",
      "expandedUrl" : "https://twitter.com/i/web/status/1397915454744633356"
    }
  },
  {
    "like" : {
      "tweetId" : "1379091675759271939",
      "fullText" : "Who installed the most concrete?\n\nCheck your answer: https://t.co/wqmmPffvwB",
      "expandedUrl" : "https://twitter.com/i/web/status/1379091675759271939"
    }
  },
  {
    "like" : {
      "tweetId" : "1387722711766650884",
      "fullText" : "I've found it, the perfect explanation of NFTs https://t.co/4JfZteww8P",
      "expandedUrl" : "https://twitter.com/i/web/status/1387722711766650884"
    }
  },
  {
    "like" : {
      "tweetId" : "1386191965981663235",
      "fullText" : "[NEW] Louis drops ANOTHER video about our research! ❤️❤️❤️ @fighttorepair 🚜🚜🚜 \n\n-&gt; https://t.co/Td6Kq7Oxjn\n\n@WillieCade7 | @GrassrootsKK\n@wabafet1 | @johnjhacking | @rej_ex | @0x686967 | @D0rkerDevil | @chiefcoolarrow | @GrassrootsKK | @kaoudis \n\nGood faith vs. APT\n\n#infosec https://t.co/RYgGsu9pFn",
      "expandedUrl" : "https://twitter.com/i/web/status/1386191965981663235"
    }
  },
  {
    "like" : {
      "tweetId" : "1329672147791269889",
      "fullText" : "任天堂様のNintendo Swichタイトル「SUPER MARIO BROS. 35」の一部楽曲のサウンド制作を弊社スタッフが担当させて頂きました。\n担当 - 江口孝宏 佐宗綾子\n公式サイト　https://t.co/f6AUJLc9Mr",
      "expandedUrl" : "https://twitter.com/i/web/status/1329672147791269889"
    }
  },
  {
    "like" : {
      "tweetId" : "1377286445178744838",
      "fullText" : "oh no https://t.co/GGBFkdLMWT",
      "expandedUrl" : "https://twitter.com/i/web/status/1377286445178744838"
    }
  },
  {
    "like" : {
      "tweetId" : "1138312630362353664",
      "fullText" : "someone give me a REAL explanation why people like this video so much, its literally me deciding to fall over in front of my phone before i get in bed https://t.co/uEig6PsjNO",
      "expandedUrl" : "https://twitter.com/i/web/status/1138312630362353664"
    }
  },
  {
    "like" : {
      "tweetId" : "1265798831486242816",
      "fullText" : "https://t.co/xyZhmSj3LR",
      "expandedUrl" : "https://twitter.com/i/web/status/1265798831486242816"
    }
  },
  {
    "like" : {
      "tweetId" : "1346510879735484426",
      "fullText" : "Lets go https://t.co/MSkZNmEnr0",
      "expandedUrl" : "https://twitter.com/i/web/status/1346510879735484426"
    }
  },
  {
    "like" : {
      "tweetId" : "1362507095904501766",
      "fullText" : "SIAMO SU MARTE!!\nDI NUOVO!!!!\n\n#Mars2020 #Perseverance https://t.co/s698CGn8Dd",
      "expandedUrl" : "https://twitter.com/i/web/status/1362507095904501766"
    }
  },
  {
    "like" : {
      "tweetId" : "1362507513032245248",
      "fullText" : "Perseverance è VIVO sulla superficie di Marte!\nIl primo scatto del rover marziano!!\n#CountdownToMars #Perseverance https://t.co/2y8dlW7Kam",
      "expandedUrl" : "https://twitter.com/i/web/status/1362507513032245248"
    }
  },
  {
    "like" : {
      "tweetId" : "1357896709846753283",
      "fullText" : "Did you know the PC Version of Horizon: Zero Dawn lets you toggle the resolution to 72p? (256x144) https://t.co/3nYccHPQDZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1357896709846753283"
    }
  },
  {
    "like" : {
      "tweetId" : "1354832177498873860",
      "fullText" : "I own $amc $nok $nakd.  I bought them with the understanding we live in a free market where people can buy and sell stocks fair and square and at their own risk.   I will hold them till the death as a reminder that @RobinhoodApp founders must go to prison",
      "expandedUrl" : "https://twitter.com/i/web/status/1354832177498873860"
    }
  },
  {
    "like" : {
      "tweetId" : "1354699649546919936",
      "fullText" : "An Open Letter to Melvin Capital, CNBC, Boomers, and WSB\n\n-u/ssauronn\n\nhttps://t.co/hOxBa9jJLK",
      "expandedUrl" : "https://twitter.com/i/web/status/1354699649546919936"
    }
  },
  {
    "like" : {
      "tweetId" : "1354712122232606720",
      "fullText" : "“The shorts have had their way with the market for decades, and no one has ever complained about it, so i am thrilled, that individual investors are playing the same game, and now you (big hedge funds) are losing” - Charles Payne.\n\nhttps://t.co/SGD6KhoRR5",
      "expandedUrl" : "https://twitter.com/i/web/status/1354712122232606720"
    }
  },
  {
    "like" : {
      "tweetId" : "1354588779403743235",
      "fullText" : "Due to the in tents load the sub was put under today from our explosive growth 🚀 the mod team has been working behind the scenes to get r/wallstreetbets back up. Please 🌈🐻 with us during this trying time. https://t.co/5DaeTk4OIr",
      "expandedUrl" : "https://twitter.com/i/web/status/1354588779403743235"
    }
  },
  {
    "like" : {
      "tweetId" : "1350182563541872640",
      "fullText" : "humanity has reached its peak https://t.co/j9RYcTcSj7",
      "expandedUrl" : "https://twitter.com/i/web/status/1350182563541872640"
    }
  },
  {
    "like" : {
      "tweetId" : "1227830338136702977",
      "fullText" : "We're wrapping up shooting season 5 of #TheExpanse . \n I just watched the 508 Director's Cut.  And I just realized we made a huge mistake.  We didn't title episode 508 \"Holy Shit Naomi Nagata is the Biggest Badass in Space.\"\n\nGod damn, you guys.  I mean, God Damn.\n\n@Mi55Tipper",
      "expandedUrl" : "https://twitter.com/i/web/status/1227830338136702977"
    }
  },
  {
    "like" : {
      "tweetId" : "1343669303103479809",
      "fullText" : "I can finally cross this off my \"to-do\" list.\n\n#BetterLateThanNever https://t.co/3rmfEiA3tv",
      "expandedUrl" : "https://twitter.com/i/web/status/1343669303103479809"
    }
  },
  {
    "like" : {
      "tweetId" : "1339285397382303745",
      "fullText" : "@JurassicRabbit Best way to fix this is add two NPCs, one yelling at the other about fucking the sign up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1339285397382303745"
    }
  },
  {
    "like" : {
      "tweetId" : "1339247032880381952",
      "fullText" : "Is this a typo, or did I miss some lore that explains how Night City's real name is actually Nigth City? https://t.co/DQgRFrtjGj",
      "expandedUrl" : "https://twitter.com/i/web/status/1339247032880381952"
    }
  },
  {
    "like" : {
      "tweetId" : "1339202014006349825",
      "fullText" : "Some of our users, primarily in Europe and the Middle East are currently experiencing connection issues. We're working to bring them back online. 🤠 Please hang on, and sorry for the inconvenience!",
      "expandedUrl" : "https://twitter.com/i/web/status/1339202014006349825"
    }
  },
  {
    "like" : {
      "tweetId" : "1338871495016136705",
      "fullText" : "SuperRT - an expansion chip for realtime raytracing on the SNES (this time with the video attached because apparently I'm good at forgetting important things).\nYoutube: https://t.co/Eo7subTBAg\nTechnical article: https://t.co/BtY9lpP90B https://t.co/Nxj25NpoBW",
      "expandedUrl" : "https://twitter.com/i/web/status/1338871495016136705"
    }
  },
  {
    "like" : {
      "tweetId" : "1338493015145504770",
      "fullText" : "Today, at 3.47AM PT Google experienced an authentication system outage for approximately 45 minutes due to an internal storage quota issue. This was resolved at 4:32AM PT, and all services are now restored.",
      "expandedUrl" : "https://twitter.com/i/web/status/1338493015145504770"
    }
  },
  {
    "like" : {
      "tweetId" : "1338455968468889600",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1338455968468889600"
    }
  },
  {
    "like" : {
      "tweetId" : "1336936563339649025",
      "fullText" : "I like this tho. https://t.co/CF9hXUindD",
      "expandedUrl" : "https://twitter.com/i/web/status/1336936563339649025"
    }
  },
  {
    "like" : {
      "tweetId" : "1335956564973408256",
      "fullText" : "@yvvxss Finn should have been the Jedi.\n\nhe'd have made a far more interesting lead than Rey.",
      "expandedUrl" : "https://twitter.com/i/web/status/1335956564973408256"
    }
  },
  {
    "like" : {
      "tweetId" : "1335995431080353802",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1335995431080353802"
    }
  },
  {
    "like" : {
      "tweetId" : "1326662743827468288",
      "fullText" : "We can't believe we have to say this, but please do not blow vape smoke into your Xbox Series X.",
      "expandedUrl" : "https://twitter.com/i/web/status/1326662743827468288"
    }
  },
  {
    "like" : {
      "tweetId" : "1310668462822428672",
      "fullText" : "TONIGHT ON FOX https://t.co/iSnLkLVZwM",
      "expandedUrl" : "https://twitter.com/i/web/status/1310668462822428672"
    }
  },
  {
    "like" : {
      "tweetId" : "926617907257335808",
      "fullText" : "@sonic_hedgehog You just https://t.co/0a5oKkZx5b",
      "expandedUrl" : "https://twitter.com/i/web/status/926617907257335808"
    }
  },
  {
    "like" : {
      "tweetId" : "926617266564743168",
      "fullText" : "@deanasawr https://t.co/aN5QH5NAla",
      "expandedUrl" : "https://twitter.com/i/web/status/926617266564743168"
    }
  },
  {
    "like" : {
      "tweetId" : "1288374623784984577",
      "fullText" : "vroom vroom 🏍💨\n#botw #zelink #LegendOfZelda #animation https://t.co/0wlgEG5dIb",
      "expandedUrl" : "https://twitter.com/i/web/status/1288374623784984577"
    }
  },
  {
    "like" : {
      "tweetId" : "1304933300612608000",
      "fullText" : "Who else is hyped? 👀\n\n楽しみにしています!\n#HyruleWarriorsAgeofCalamity #procreateart https://t.co/gNbLnLM757",
      "expandedUrl" : "https://twitter.com/i/web/status/1304933300612608000"
    }
  },
  {
    "like" : {
      "tweetId" : "1304835687561134085",
      "fullText" : "outfit doodles https://t.co/umB2hQ50v4",
      "expandedUrl" : "https://twitter.com/i/web/status/1304835687561134085"
    }
  },
  {
    "like" : {
      "tweetId" : "1304029509260251136",
      "fullText" : "hello !! as promised, here are the telegram stickers for wolf link! :) thank you for all the suggestions, and for enjoying my content! 💖💖\n\nyou can get them for free here: https://t.co/tlwsp8K1SC\n\nalso if you'd like, you can support me here! https://t.co/h8YWkH2c4Y ☕ https://t.co/RaPs9Q8Uh6",
      "expandedUrl" : "https://twitter.com/i/web/status/1304029509260251136"
    }
  },
  {
    "like" : {
      "tweetId" : "1159455736235061249",
      "fullText" : "@iamdevloper When the moon hits your eye \nlike a big pizza pie, that's amore\n\nwhen file you don't need\nexceeds 50 MB,\n.gitignore",
      "expandedUrl" : "https://twitter.com/i/web/status/1159455736235061249"
    }
  },
  {
    "like" : {
      "tweetId" : "1290403889921921025",
      "fullText" : "@EA oh shit oh fuck",
      "expandedUrl" : "https://twitter.com/i/web/status/1290403889921921025"
    }
  },
  {
    "like" : {
      "tweetId" : "1290353654256435200",
      "fullText" : "@pentaerythrit0l Stay where you are.",
      "expandedUrl" : "https://twitter.com/i/web/status/1290353654256435200"
    }
  },
  {
    "like" : {
      "tweetId" : "1289820490312200192",
      "fullText" : "the secret meaning behind the EA logo https://t.co/Ht4WLM2zeJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1289820490312200192"
    }
  },
  {
    "like" : {
      "tweetId" : "1292312967661285376",
      "fullText" : "THE TWIST GOT ME GOOD 😂 https://t.co/72ayuJpq8w",
      "expandedUrl" : "https://twitter.com/i/web/status/1292312967661285376"
    }
  },
  {
    "like" : {
      "tweetId" : "1291372176889860096",
      "fullText" : "夏ー☀️ https://t.co/az6DI0u6fd",
      "expandedUrl" : "https://twitter.com/i/web/status/1291372176889860096"
    }
  },
  {
    "like" : {
      "tweetId" : "1253606734473486338",
      "fullText" : "新しい機能が準備できました。 https://t.co/2FJvfqZruA",
      "expandedUrl" : "https://twitter.com/i/web/status/1253606734473486338"
    }
  },
  {
    "like" : {
      "tweetId" : "1253608206330281985",
      "fullText" : "いまのうちならまだ古代武器で戦うおひぃさまも古代兵装コスのおひぃさまも妄想できるんだなこれが。 https://t.co/SAw24OyHO8",
      "expandedUrl" : "https://twitter.com/i/web/status/1253608206330281985"
    }
  },
  {
    "like" : {
      "tweetId" : "1247990514533580800",
      "fullText" : "@flcnhvy @thirdrowtesla AddLabel -&gt; PersonDressedAsCone",
      "expandedUrl" : "https://twitter.com/i/web/status/1247990514533580800"
    }
  },
  {
    "like" : {
      "tweetId" : "1268349997344530432",
      "fullText" : "Couldnt resist picking up a $99 Nintendo New 2DS XL. Going to make a vid modding  it, loading it up with homebrew and giving it away to one lucky person next week",
      "expandedUrl" : "https://twitter.com/i/web/status/1268349997344530432"
    }
  },
  {
    "like" : {
      "tweetId" : "1084402518388424704",
      "fullText" : "You know a data breach is big when... https://t.co/rtWMdq0Cpt",
      "expandedUrl" : "https://twitter.com/i/web/status/1084402518388424704"
    }
  },
  {
    "like" : {
      "tweetId" : "1265514698717437954",
      "fullText" : "Well nerds, I fuckin' did it.\n\nTook me a global pandemic and a damn quarantine, but I did it.\n\nI figured out the precise chronological order of all the MCU movies (so far) BY SCENE.\n\nI'm out of my Goddamn mind. You're welcome. https://t.co/3VXjqk4kjQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1265514698717437954"
    }
  },
  {
    "like" : {
      "tweetId" : "1246647165360861185",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1246647165360861185"
    }
  },
  {
    "like" : {
      "tweetId" : "1258470041743314944",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1258470041743314944"
    }
  },
  {
    "like" : {
      "tweetId" : "1261298081020227589",
      "fullText" : "@animalcrossing I love this, please consider doing more virtual performances!",
      "expandedUrl" : "https://twitter.com/i/web/status/1261298081020227589"
    }
  },
  {
    "like" : {
      "tweetId" : "1247940726328922112",
      "fullText" : "Windows 10 Build 19603 came out today with a great new WSL feature: Explore your Linux files inside of File Explorer! https://t.co/uQaVavoaBX https://t.co/WTWFFt192b",
      "expandedUrl" : "https://twitter.com/i/web/status/1247940726328922112"
    }
  },
  {
    "like" : {
      "tweetId" : "1251234873332899841",
      "fullText" : "@GeneralSamsSec here you go u absolute sexist https://t.co/Va3Ai3eUuW",
      "expandedUrl" : "https://twitter.com/i/web/status/1251234873332899841"
    }
  },
  {
    "like" : {
      "tweetId" : "1239986581597032448",
      "fullText" : "This was a picture taken of the Venice canals just last summer. Just look how dirty it looks https://t.co/IhjxHQFqaX",
      "expandedUrl" : "https://twitter.com/i/web/status/1239986581597032448"
    }
  },
  {
    "like" : {
      "tweetId" : "1240644857510727680",
      "fullText" : "@Kotaku Thats cool, except surgical masks don't help against corona",
      "expandedUrl" : "https://twitter.com/i/web/status/1240644857510727680"
    }
  },
  {
    "like" : {
      "tweetId" : "1239860872119496704",
      "fullText" : "Thought I’d spread abit of positivity for you guys. Since the lockdown of Venice without the pollution from boats the water has been begun to clear up and a dolphin has been spotted in the canal for the first time in nearly 60 years! #venice https://t.co/dbq4mGhfnp",
      "expandedUrl" : "https://twitter.com/i/web/status/1239860872119496704"
    }
  },
  {
    "like" : {
      "tweetId" : "1240455638578331649",
      "fullText" : "@FrancescoPlatan @patchbaobao @AlecMacGillis @ChicagoBernie Rooting for you all in Italy.\nWe all earthlings got everything to lose.\nTogether we stand against the virus. And we will prevail together.",
      "expandedUrl" : "https://twitter.com/i/web/status/1240455638578331649"
    }
  },
  {
    "like" : {
      "tweetId" : "1240302596407132161",
      "fullText" : "@FrancescoPlatan @AlecMacGillis @ChicagoBernie We love Italy here in the US! Praying for the Italian people. 🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1240302596407132161"
    }
  },
  {
    "like" : {
      "tweetId" : "1240289080082128896",
      "fullText" : "@AlecMacGillis Hi Alec, thanks so much for spreading the word on this…  I created dashboard with #COVID19italia data by region.  Was curious about the impact of Veneto’s aggressive testing approach. They’re faring better than adjacent regions in several stats.  See: https://t.co/7V0BSNKYoF",
      "expandedUrl" : "https://twitter.com/i/web/status/1240289080082128896"
    }
  },
  {
    "like" : {
      "tweetId" : "1240281920220651527",
      "fullText" : "@AlecMacGillis @thegarance So we still don’t know why the Trump admin didn’t use the same test as the rest of the world??",
      "expandedUrl" : "https://twitter.com/i/web/status/1240281920220651527"
    }
  },
  {
    "like" : {
      "tweetId" : "1240279081293352964",
      "fullText" : "How one small town at the center of the outbreak has cut infections virtually to zero: test all 3,300 in town, isolate the 3 percent who tested positive. Infection rate 10 days later down to .3 percent. https://t.co/5Tgpa7cCgl https://t.co/qlydmYJ0mM",
      "expandedUrl" : "https://twitter.com/i/web/status/1240279081293352964"
    }
  },
  {
    "like" : {
      "tweetId" : "1239665509596983296",
      "fullText" : "Okay we jinxed ourselves. Team is aware of the connection issues and are working on it. https://t.co/dAvjEAxJuZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1239665509596983296"
    }
  },
  {
    "like" : {
      "tweetId" : "1239662748881104898",
      "fullText" : "coronavirus has even murdered @discordapp now",
      "expandedUrl" : "https://twitter.com/i/web/status/1239662748881104898"
    }
  },
  {
    "like" : {
      "tweetId" : "1238126309710184448",
      "fullText" : "Code work on the Steam version of Dwarf Fortress is underway!🔨\n\nTime to start getting graphics in and party like it's.. uh, 1987, or something. Heh.\n\n⚒️Read: https://t.co/QQRQeDXteu\n⚒️Sign up for the newsletter to get the biweekly updates: https://t.co/CRkxa1SsCV https://t.co/JgkX9RITZw",
      "expandedUrl" : "https://twitter.com/i/web/status/1238126309710184448"
    }
  },
  {
    "like" : {
      "tweetId" : "1234543551893180417",
      "fullText" : "Finally getting to doing Jaguar GD stuff again! Woo! I'm basically now waiting on things for the Lynx and NeoPocket GD's, so I've just laid up the programmer / tester device for the Jag GD. Things are moving ever closer. Albeit at a moderately fast snails pace... https://t.co/I02CZg9vI1",
      "expandedUrl" : "https://twitter.com/i/web/status/1234543551893180417"
    }
  },
  {
    "like" : {
      "tweetId" : "1235626137197436929",
      "fullText" : "#coronavirus: dichiarazione del Presidente #Mattarella https://t.co/QJanArqBhw",
      "expandedUrl" : "https://twitter.com/i/web/status/1235626137197436929"
    }
  },
  {
    "like" : {
      "tweetId" : "1231366168184852482",
      "fullText" : "@realDonaldTrump At this point I wouldn't be totally surprised if Trump ever retweets one of my memes",
      "expandedUrl" : "https://twitter.com/i/web/status/1231366168184852482"
    }
  },
  {
    "like" : {
      "tweetId" : "1211866930740695041",
      "fullText" : "@mikeshapiroland Oh my god what the fuck",
      "expandedUrl" : "https://twitter.com/i/web/status/1211866930740695041"
    }
  },
  {
    "like" : {
      "tweetId" : "1204847353259274240",
      "fullText" : "It was a very close battle between Nyan Cat and Supa Hot Fire but Nyan Cat emerged victorious as the best meme of 2011!\n\nNow you can vote for the best 2012 meme here:\nhttps://t.co/X2CNmqlpP7\n\n(Again feel free to suggest any missed memes from 2012) https://t.co/Yd9BkdgqZp",
      "expandedUrl" : "https://twitter.com/i/web/status/1204847353259274240"
    }
  },
  {
    "like" : {
      "tweetId" : "1204489138248048640",
      "fullText" : "You chose Epic Sax Guy as the best meme of 2010!\n(Ignore the blue in the pie chart someone just bot voted for Ok Boomer over 300,000 times)\n\nYou can now vote for the best 2011 meme here: https://t.co/j8IS0mVU86\n\n(Again feel free to suggest any missed memes &gt;&gt;&gt;FROM 2011&lt;&lt;&lt;) https://t.co/NIl10YdlZx",
      "expandedUrl" : "https://twitter.com/i/web/status/1204489138248048640"
    }
  },
  {
    "like" : {
      "tweetId" : "1204134518359232514",
      "fullText" : "Ok I've had to make it require you to be signed in to a Google account cause someone must have used a bot to vote for \"Ok boomer\" 393,850 times https://t.co/yl3W2qMYM5",
      "expandedUrl" : "https://twitter.com/i/web/status/1204134518359232514"
    }
  },
  {
    "like" : {
      "tweetId" : "1203410596911308800",
      "fullText" : "I need your help to make the Meme of the Decade vote as good as possible. So far I've compiled this list of memes for every year, but I'm sure I may have missed some big ones, especially in the year 2013 where I've barely put any memes yet. Also feel free to suggest corrections. https://t.co/PyIB0vRJkT",
      "expandedUrl" : "https://twitter.com/i/web/status/1203410596911308800"
    }
  },
  {
    "like" : {
      "tweetId" : "1203435531222364160",
      "fullText" : "Top 5 video games of the decade (objectively):\n\n1. The Witcher 3\n2. Minecraft\n3. God of War\n4. The Last of Us\n5. Detroit Become Human",
      "expandedUrl" : "https://twitter.com/i/web/status/1203435531222364160"
    }
  },
  {
    "like" : {
      "tweetId" : "1203438236988821504",
      "fullText" : "Top 5 video games of the decade (controversial version):\n\n1. Raid Shadow Legends\n2. Fortnite\n3. Metal Gear Survive\n4. Fallout 76\n5. No Man's Sky",
      "expandedUrl" : "https://twitter.com/i/web/status/1203438236988821504"
    }
  },
  {
    "like" : {
      "tweetId" : "1204128001023238144",
      "fullText" : "The Meme of the Decade polls are now on! I will post a daily poll for each year. Today you can vote for the best meme from 2010. You can do that here: https://t.co/E1sKoaRgL4\n\n(Also you can still suggest any missed memes, I can add them in if suggested quickly after this tweet) https://t.co/u45Mw7UmAw",
      "expandedUrl" : "https://twitter.com/i/web/status/1204128001023238144"
    }
  },
  {
    "like" : {
      "tweetId" : "1189741245125595136",
      "fullText" : "#CharlieCox as Loki &amp; @twhiddleston as Daredevil just won Halloween from now til forever, y’all. #BetrayalBroadway #SaveDaredevil https://t.co/oZpHbrFP03",
      "expandedUrl" : "https://twitter.com/i/web/status/1189741245125595136"
    }
  },
  {
    "like" : {
      "tweetId" : "1187464121349898242",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1187464121349898242"
    }
  },
  {
    "like" : {
      "tweetId" : "1145757251787010048",
      "fullText" : "@Windows Wait, you're telling me computers can tell the time now!? This is truly the peak of technology!",
      "expandedUrl" : "https://twitter.com/i/web/status/1145757251787010048"
    }
  },
  {
    "like" : {
      "tweetId" : "1145803750990385154",
      "fullText" : "@CosmicConsole And Reversi, CAN YOU BELIEVE IT?",
      "expandedUrl" : "https://twitter.com/i/web/status/1145803750990385154"
    }
  },
  {
    "like" : {
      "tweetId" : "1145756746754842624",
      "fullText" : "@Windows can't wait for this :D https://t.co/YUOd0pcMB5",
      "expandedUrl" : "https://twitter.com/i/web/status/1145756746754842624"
    }
  },
  {
    "like" : {
      "tweetId" : "1145764507064643586",
      "fullText" : "@NikoWibisono It'll be totally wicked.",
      "expandedUrl" : "https://twitter.com/i/web/status/1145764507064643586"
    }
  },
  {
    "like" : {
      "tweetId" : "1145751924022677504",
      "fullText" : "@Greggy_Lucas Of course! It's sick.",
      "expandedUrl" : "https://twitter.com/i/web/status/1145751924022677504"
    }
  },
  {
    "like" : {
      "tweetId" : "1145739997510873088",
      "fullText" : "@Windows But does it have a calculator?",
      "expandedUrl" : "https://twitter.com/i/web/status/1145739997510873088"
    }
  },
  {
    "like" : {
      "tweetId" : "1145746331140579328",
      "fullText" : "@realblondewolf Cheeuh! That's what we like to hear.",
      "expandedUrl" : "https://twitter.com/i/web/status/1145746331140579328"
    }
  },
  {
    "like" : {
      "tweetId" : "1145732626017222656",
      "expandedUrl" : "https://twitter.com/i/web/status/1145732626017222656"
    }
  },
  {
    "like" : {
      "tweetId" : "1129274835173908481",
      "fullText" : "And I am forever grateful https://t.co/kU1pT8t0yv",
      "expandedUrl" : "https://twitter.com/i/web/status/1129274835173908481"
    }
  },
  {
    "like" : {
      "tweetId" : "1119682892802736128",
      "fullText" : "@ikaripress This!☝️ https://t.co/s3ErXjlmA8",
      "expandedUrl" : "https://twitter.com/i/web/status/1119682892802736128"
    }
  },
  {
    "like" : {
      "tweetId" : "1119375409638981633",
      "fullText" : "@davariusjessup @ikaripress Yeah sure...that’s it. 😂 https://t.co/EqQ6NtNxcI",
      "expandedUrl" : "https://twitter.com/i/web/status/1119375409638981633"
    }
  },
  {
    "like" : {
      "tweetId" : "1119230350956404741",
      "fullText" : "Facts! https://t.co/HdU42syLeU",
      "expandedUrl" : "https://twitter.com/i/web/status/1119230350956404741"
    }
  },
  {
    "like" : {
      "tweetId" : "1019720197635297281",
      "fullText" : "I still don’t think enough people have seen this https://t.co/q2niskoHOU",
      "expandedUrl" : "https://twitter.com/i/web/status/1019720197635297281"
    }
  },
  {
    "like" : {
      "tweetId" : "1089433776533327872",
      "fullText" : "Dear universe. Please never let this end. \n\nhttps://t.co/BStc2xhGYg\n\n@reddit is the best.",
      "expandedUrl" : "https://twitter.com/i/web/status/1089433776533327872"
    }
  },
  {
    "like" : {
      "tweetId" : "1092271438965411841",
      "fullText" : "@elonmusk I can't believe you're showing us a brand new engine the minute it's test fired. That's pretty unheard of in the industry... also massively exciting! Congrats!!! What's next? Work on duration? Get it up to a few minutes, ship it down and stick it on ole' StarHopper? 🤔",
      "expandedUrl" : "https://twitter.com/i/web/status/1092271438965411841"
    }
  },
  {
    "like" : {
      "tweetId" : "1064520611517452288",
      "fullText" : "You guys wanted the #Quickswitch #billionaireboysclub next so here they are - #ElseBothworlds @RobertDowneyJr @BenAffleck #batman #ironman https://t.co/0rx0j0vYM4",
      "expandedUrl" : "https://twitter.com/i/web/status/1064520611517452288"
    }
  },
  {
    "like" : {
      "tweetId" : "844315562196975616",
      "fullText" : "#Champions my Friends\n&amp; We'll keep on fighting till the end\n\nDUN DUN DUN🎼\n\n⚜️https://t.co/1Dzk4pxIaP\n⚜️https://t.co/6BpEdvUjMn\n#CustomAmiibo https://t.co/5g8w8L2SZ1",
      "expandedUrl" : "https://twitter.com/i/web/status/844315562196975616"
    }
  },
  {
    "like" : {
      "tweetId" : "574520030991421440",
      "fullText" : "@stefa168 Good! Now don't forget it ever again :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/574520030991421440"
    }
  },
  {
    "like" : {
      "tweetId" : "365931742386860032",
      "fullText" : "@stefa168 - Thanks for the support, man.  You rock!",
      "expandedUrl" : "https://twitter.com/i/web/status/365931742386860032"
    }
  },
  {
    "like" : {
      "tweetId" : "363074566609842178",
      "fullText" : "Giveaway: Reply on Twitter/Facebook to be randomly chosen for a free 768MB server on Saturday! Retweet/Share = 2X chance!",
      "expandedUrl" : "https://twitter.com/i/web/status/363074566609842178"
    }
  },
  {
    "like" : {
      "tweetId" : "277227894625943552",
      "fullText" : "@Marc_IRL I can't imagine how an angry grandparent would send an email xD",
      "expandedUrl" : "https://twitter.com/i/web/status/277227894625943552"
    }
  },
  {
    "like" : {
      "tweetId" : "277223601441218563",
      "fullText" : "WHEN I GET EMAILS IN ALL CAPS THEY ARE USUALLY NOT ANGRY THEY ARE USUALLY GRANDPARENTS",
      "expandedUrl" : "https://twitter.com/i/web/status/277223601441218563"
    }
  },
  {
    "like" : {
      "tweetId" : "236941095387418624",
      "fullText" : "io faccio amicizia meglio coi ragazzi perché le ragazze sono delle streghe: sono selettive e una volta formato il gruppo nessuno entra più.",
      "expandedUrl" : "https://twitter.com/i/web/status/236941095387418624"
    }
  },
  {
    "like" : {
      "tweetId" : "235016445531131904",
      "fullText" : "AR.Drone mod: NASCAR - style! http://t.co/tpTGT2jk",
      "expandedUrl" : "https://twitter.com/i/web/status/235016445531131904"
    }
  },
  {
    "like" : {
      "tweetId" : "234738486949859328",
      "fullText" : "Prima di spegnere il braciere, ricordatevi di metterci dentro gli One Direction per almeno un secondo. #Londra2012 #ClosingCeremony",
      "expandedUrl" : "https://twitter.com/i/web/status/234738486949859328"
    }
  },
  {
    "like" : {
      "tweetId" : "234758810068193280",
      "fullText" : "imagine - john lennon. beh, come si fa a non amare questa canzone?",
      "expandedUrl" : "https://twitter.com/i/web/status/234758810068193280"
    }
  },
  {
    "like" : {
      "tweetId" : "230642377390440448",
      "fullText" : "The updated has been submitted but there was a problem, we're currently waiting for more information.",
      "expandedUrl" : "https://twitter.com/i/web/status/230642377390440448"
    }
  },
  {
    "like" : {
      "tweetId" : "216425462824583168",
      "fullText" : "@stefa168 Great that it worked out for you!",
      "expandedUrl" : "https://twitter.com/i/web/status/216425462824583168"
    }
  },
  {
    "like" : {
      "tweetId" : "216448696517279744",
      "fullText" : "AHAHAHAHAHAHAHAH, ODDIO MUOIO, ANDATE A VEDERE COME GOOGLE TRADUTTORE PRONUNCIA 'AGHI' IN ITALIANO! AHAHAHAHAHAHAHAHAHAHAHAH",
      "expandedUrl" : "https://twitter.com/i/web/status/216448696517279744"
    }
  },
  {
    "like" : {
      "tweetId" : "216257858365423616",
      "fullText" : "#takeshiscastletime! :D",
      "expandedUrl" : "https://twitter.com/i/web/status/216257858365423616"
    }
  },
  {
    "like" : {
      "tweetId" : "214683169482473473",
      "fullText" : "mamma mia, quel vecchietto. poovero. ma cosa è successo alla fine del brano? oò #invalsi",
      "expandedUrl" : "https://twitter.com/i/web/status/214683169482473473"
    }
  },
  {
    "like" : {
      "tweetId" : "212944994342944768",
      "fullText" : "@jeb_ @brunothepig wait! No! better idea! You are a spectator until someone builds a steve golem for you to possess!",
      "expandedUrl" : "https://twitter.com/i/web/status/212944994342944768"
    }
  },
  {
    "like" : {
      "tweetId" : "212933664982581248",
      "fullText" : "@minecraftzx It's not Thursday yet",
      "expandedUrl" : "https://twitter.com/i/web/status/212933664982581248"
    }
  },
  {
    "like" : {
      "tweetId" : "208960934968967168",
      "fullText" : "LA PRIMA COSA CHE NOTANO I NOSTRI IDOLI IN ITALIA? IL CIBO. #WTF",
      "expandedUrl" : "https://twitter.com/i/web/status/208960934968967168"
    }
  },
  {
    "like" : {
      "tweetId" : "208953705012277248",
      "fullText" : "@stefa168 ahahahahahahahah, oddio, questo è poco ma sicuro :'D",
      "expandedUrl" : "https://twitter.com/i/web/status/208953705012277248"
    }
  },
  {
    "like" : {
      "tweetId" : "207132838267600896",
      "fullText" : "@TheMacintoth Hehe fun idea",
      "expandedUrl" : "https://twitter.com/i/web/status/207132838267600896"
    }
  },
  {
    "like" : {
      "tweetId" : "207036238753038337",
      "fullText" : "No, I will not trade with you, Creeper :[ http://t.co/dEsVufNB",
      "expandedUrl" : "https://twitter.com/i/web/status/207036238753038337"
    }
  },
  {
    "like" : {
      "tweetId" : "190758216844574720",
      "fullText" : "Scrolls is getting closer to alpha. We're having internal tournaments at the office every week. @xlson seems to be the man to beat.",
      "expandedUrl" : "https://twitter.com/i/web/status/190758216844574720"
    }
  },
  {
    "like" : {
      "tweetId" : "190758735596097536",
      "fullText" : "@carlmanneh Sounds like a wicked green screen set!",
      "expandedUrl" : "https://twitter.com/i/web/status/190758735596097536"
    }
  },
  {
    "like" : {
      "tweetId" : "190479459059642370",
      "fullText" : "The eggs spawning children is a bug - sorry :(",
      "expandedUrl" : "https://twitter.com/i/web/status/190479459059642370"
    }
  },
  {
    "like" : {
      "tweetId" : "1817264604478947510",
      "fullText" : "Let her cook\n#まほあこ #魔法少女にあこがれて https://t.co/OkykwlrW0Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1817264604478947510"
    }
  },
  {
    "like" : {
      "tweetId" : "1817861312510353759",
      "fullText" : "まほあこ新刊表紙( ) https://t.co/Edg5EkpsDT",
      "expandedUrl" : "https://twitter.com/i/web/status/1817861312510353759"
    }
  },
  {
    "like" : {
      "tweetId" : "1817968870227067401",
      "fullText" : "🤖…. https://t.co/oOPef3PTau",
      "expandedUrl" : "https://twitter.com/i/web/status/1817968870227067401"
    }
  },
  {
    "like" : {
      "tweetId" : "1818244213693411730",
      "fullText" : "alt. https://t.co/HAgwrOZIVQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1818244213693411730"
    }
  },
  {
    "like" : {
      "tweetId" : "1819625066419966439",
      "fullText" : "#まほあこ https://t.co/FGZyHLmS5Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1819625066419966439"
    }
  },
  {
    "like" : {
      "tweetId" : "1820955303741198788",
      "fullText" : "Nero alice's Stand: Roboko\n#まほあこ #魔法少女にあこがれて https://t.co/cP3lsJjHjY",
      "expandedUrl" : "https://twitter.com/i/web/status/1820955303741198788"
    }
  },
  {
    "like" : {
      "tweetId" : "1822366499958362243",
      "fullText" : "#まほあこSM大感謝祭 #まほあこ https://t.co/zM0BwN6gHx",
      "expandedUrl" : "https://twitter.com/i/web/status/1822366499958362243"
    }
  },
  {
    "like" : {
      "tweetId" : "1822682417246715957",
      "fullText" : "💙🐮\n#まほあこSM大感謝祭 #まほあこ https://t.co/3fG9VoGplv",
      "expandedUrl" : "https://twitter.com/i/web/status/1822682417246715957"
    }
  },
  {
    "like" : {
      "tweetId" : "1823365734774218786",
      "fullText" : "🦁💛❤️🐰\n#まほあこ #まほあこSM大感謝祭 https://t.co/9KfdqUnUun",
      "expandedUrl" : "https://twitter.com/i/web/status/1823365734774218786"
    }
  },
  {
    "like" : {
      "tweetId" : "1823645740167528828",
      "fullText" : "✨イベントビジュアル毎日公開✨\n\nTVア二メ「#魔法少女にあこがれて」\nイベント #まほあこSM大感謝祭\n\nイベントビジュアルを\n毎日1キャラずつ公開中！\n8人目は…姉母ネモ✨\n\n#まほあこ S(Special)M(Memories)シーンを\nアンケートにて募集中✨\nhttps://t.co/0fgC7bguYa https://t.co/9pH9M2Al3C",
      "expandedUrl" : "https://twitter.com/i/web/status/1823645740167528828"
    }
  },
  {
    "like" : {
      "tweetId" : "1823747604527898719",
      "fullText" : "more https://t.co/Mt8gDz8CC6 https://t.co/Broka2Gjpv",
      "expandedUrl" : "https://twitter.com/i/web/status/1823747604527898719"
    }
  },
  {
    "like" : {
      "tweetId" : "1823806802464833699",
      "fullText" : "🐶💙💜🐶\n#まほあこSM大感謝祭 #まほあこ https://t.co/sQc9iY1Ceq",
      "expandedUrl" : "https://twitter.com/i/web/status/1823806802464833699"
    }
  },
  {
    "like" : {
      "tweetId" : "1819502869307183487",
      "fullText" : "Modern MoGal #325 -  Special outfit 🐈📦\n\n#modernmogal https://t.co/TcsUENEdUf",
      "expandedUrl" : "https://twitter.com/i/web/status/1819502869307183487"
    }
  },
  {
    "like" : {
      "tweetId" : "1793928036683002120",
      "fullText" : "Rest in peace, Kabosu-chan 🫡🧡💛\n#doge https://t.co/rxOcGyHVYF",
      "expandedUrl" : "https://twitter.com/i/web/status/1793928036683002120"
    }
  },
  {
    "like" : {
      "tweetId" : "1813728557958590890",
      "fullText" : "We’ve officially passed 100 days, 2400 hours, since the Nintendo Network shutdown at 8PM EDT on April 8, 2024. \n\nCongratulations @fishguy6564!",
      "expandedUrl" : "https://twitter.com/i/web/status/1813728557958590890"
    }
  },
  {
    "like" : {
      "tweetId" : "1813316213457752268",
      "fullText" : "@UnstPhoenix Today is day 99",
      "expandedUrl" : "https://twitter.com/i/web/status/1813316213457752268"
    }
  },
  {
    "like" : {
      "tweetId" : "1813282591312912722",
      "fullText" : "SlitherySheep has disconnected from Super Mario Maker, marking the true end of the Nintendo Network on the Wii U.\n\nFishguy6564 remains on Mario Kart 7, watching Lakitu run victory laps, as the final known player on the Nintendo Network. https://t.co/f7cw7wOBan",
      "expandedUrl" : "https://twitter.com/i/web/status/1813282591312912722"
    }
  },
  {
    "like" : {
      "tweetId" : "1808733541770867065",
      "fullText" : "Just wanted to thank everyone for all the fanart and love you are giving the Steam Delivery Girl 🥺✨💖 https://t.co/h2ZxNm7N2T",
      "expandedUrl" : "https://twitter.com/i/web/status/1808733541770867065"
    }
  },
  {
    "like" : {
      "tweetId" : "1447979697619472388",
      "fullText" : "Hey, it's #PortfolioDay again! \nI'm Nemu, an artist based in Chile. I love drawing cute things and taking naps.\n\n🐯 https://t.co/crki9NoArv\n\n🛒https://t.co/PTuNHC2Ms6\n🛒https://t.co/00FeVoZeGc\n\n✨https://t.co/DYPfUndkw5\n✨https://t.co/sVXAX9hjjT\n\n💌nemupanart@gmail.com https://t.co/DFh5Uoga1b",
      "expandedUrl" : "https://twitter.com/i/web/status/1447979697619472388"
    }
  },
  {
    "like" : {
      "tweetId" : "1811444541716656143",
      "fullText" : "Meloni's eye rolling is something else 🙄\n\nhttps://t.co/Shuy8OE5fD",
      "expandedUrl" : "https://twitter.com/i/web/status/1811444541716656143"
    }
  },
  {
    "like" : {
      "tweetId" : "1811440377963880526",
      "fullText" : "Nun le famo due faccette alla Nato? https://t.co/W1SL65IClZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1811440377963880526"
    }
  },
  {
    "like" : {
      "tweetId" : "1808950508163359011",
      "fullText" : "https://t.co/mtCr2GFNOZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1808950508163359011"
    }
  },
  {
    "like" : {
      "tweetId" : "1801324205453230535",
      "fullText" : "@Pilestedt The one on the left! https://t.co/Jtc5kNQenS",
      "expandedUrl" : "https://twitter.com/i/web/status/1801324205453230535"
    }
  },
  {
    "like" : {
      "tweetId" : "1801320055767974108",
      "fullText" : "@Pilestedt I would pay for this. If it was to be a thing. Like $10",
      "expandedUrl" : "https://twitter.com/i/web/status/1801320055767974108"
    }
  },
  {
    "like" : {
      "tweetId" : "1801349783996510310",
      "fullText" : "@Pilestedt Did we all have the same blanket as a child?",
      "expandedUrl" : "https://twitter.com/i/web/status/1801349783996510310"
    }
  },
  {
    "like" : {
      "tweetId" : "1801184859945341058",
      "fullText" : "@Pilestedt @helldivers2 I love how you are making a lot of the less desired stratagems/weapons shine in the field again with these changes. It's a great start and I hope to see this happen with more stuff in the game!",
      "expandedUrl" : "https://twitter.com/i/web/status/1801184859945341058"
    }
  },
  {
    "like" : {
      "tweetId" : "1801185696725561635",
      "fullText" : "@Pilestedt @helldivers2 two things i wished to see:\n1. shrapnel back with the eruptor or giving heavy armor pen\n2. bigger explosion radius on the 500kg. just feels to me that the radius of the actual aoe damage doesn't match the visuals like the hellbomb does\n\nbut this patch was a MASSIVE W. AH cooked🦅 https://t.co/bLRpwaZ7nf",
      "expandedUrl" : "https://twitter.com/i/web/status/1801185696725561635"
    }
  },
  {
    "like" : {
      "tweetId" : "1801190675930812872",
      "fullText" : "@Pilestedt @helldivers2 Thank you @Pilestedt https://t.co/WvktrFfZwm",
      "expandedUrl" : "https://twitter.com/i/web/status/1801190675930812872"
    }
  },
  {
    "like" : {
      "tweetId" : "1801185123972288766",
      "fullText" : "@Pilestedt @helldivers2 \"The SEAF Artillery stratagem is no longer blocked by stratagem jammers or Ion Storms, and is available after the mission timer ends and the destroyer leaves close orbit\"\n\nSuch a specific but wonderful change, really makes that objective feel unique",
      "expandedUrl" : "https://twitter.com/i/web/status/1801185123972288766"
    }
  },
  {
    "like" : {
      "tweetId" : "1801184421380509842",
      "fullText" : "So, patch for @helldivers2 is out. What's your thoughts? What's the best / worst? Anything you want to see improved for the next patch?",
      "expandedUrl" : "https://twitter.com/i/web/status/1801184421380509842"
    }
  },
  {
    "like" : {
      "tweetId" : "1801319285647700162",
      "fullText" : "I am so glad that you all are happy about the patch and the direction of the game. I want to take this opportunity to do a massive shout-out to the teams at @ArrowheadGS that took your feedback to heart and ensured we all got back on track!\n\nWe will keep moving in this direction…",
      "expandedUrl" : "https://twitter.com/i/web/status/1801319285647700162"
    }
  },
  {
    "like" : {
      "tweetId" : "1801319921911050288",
      "fullText" : "Right in the childhood 🤣 https://t.co/zlVMY3aUs2",
      "expandedUrl" : "https://twitter.com/i/web/status/1801319921911050288"
    }
  },
  {
    "like" : {
      "tweetId" : "1801614866274521125",
      "fullText" : "@Joaguww @Pilestedt @helldivers2 @ArrowheadGS IS THAT SOME MOTHERFUCKIN CAR CARPET CITY?!\n\nWHY IS THIS NOT IN THE GAME ALREADY?! 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1801614866274521125"
    }
  },
  {
    "like" : {
      "tweetId" : "1801624865717322114",
      "fullText" : "@Joaguww @Pilestedt @helldivers2 @ArrowheadGS If the money go to a good cause, I'll pay ridiculous amounts for this cape!",
      "expandedUrl" : "https://twitter.com/i/web/status/1801624865717322114"
    }
  },
  {
    "like" : {
      "tweetId" : "1801608912220704919",
      "fullText" : "@KulaJesse94992 @helldivers2 @ArrowheadGS Yep. Give or take a couple of millions.",
      "expandedUrl" : "https://twitter.com/i/web/status/1801608912220704919"
    }
  },
  {
    "like" : {
      "tweetId" : "1801604370699518067",
      "fullText" : "@Pilestedt @helldivers2 @ArrowheadGS Okay now this, this is the good shit I love to see &amp; want to see more ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1801604370699518067"
    }
  },
  {
    "like" : {
      "tweetId" : "1801611461476946418",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1801611461476946418"
    }
  },
  {
    "like" : {
      "tweetId" : "1801606833519661309",
      "fullText" : "@Pilestedt @helldivers2 @ArrowheadGS Wait, what were you gonna do if we went for the mines?? \n\n(New patch feels great btw, assault rifles are a blast)",
      "expandedUrl" : "https://twitter.com/i/web/status/1801606833519661309"
    }
  },
  {
    "like" : {
      "tweetId" : "1801608647472013804",
      "fullText" : "@PotatoBomb3 @helldivers2 @ArrowheadGS You wouldn't want to know... 🫠",
      "expandedUrl" : "https://twitter.com/i/web/status/1801608647472013804"
    }
  },
  {
    "like" : {
      "tweetId" : "1801603873502638151",
      "fullText" : "Since the @helldivers2 community chose to save the children, @arrowheadgs does the same. We have made a donation to, well, Save the Children.\n\nGreat job Divers!\n\nhttps://t.co/080PL27Y1u https://t.co/yNhpiFWMlz",
      "expandedUrl" : "https://twitter.com/i/web/status/1801603873502638151"
    }
  },
  {
    "like" : {
      "tweetId" : "1797139746273313039",
      "fullText" : "https://t.co/3PhJ2BGuDF https://t.co/pGROBjG1hq",
      "expandedUrl" : "https://twitter.com/i/web/status/1797139746273313039"
    }
  },
  {
    "like" : {
      "tweetId" : "1796205656334028938",
      "fullText" : "MAJOR ORDER: OPERATION \"ENDURING PEACE\"\n\nThe time has come. We must eradicate the Meridia Supercolony via experimental deployment of weaponized Dark Fluid.\n\nThe destruction of an entire planet is a tragedy - but the tyrannical Terminids leave us no choice. Good luck, Helldivers. https://t.co/155a9bCnfV",
      "expandedUrl" : "https://twitter.com/i/web/status/1796205656334028938"
    }
  },
  {
    "like" : {
      "tweetId" : "1793270389541400753",
      "fullText" : "@Pilestedt @ShamsJorjani @ArrowheadGS As CCO, what is your direction in receiving and reviewing player feedback?",
      "expandedUrl" : "https://twitter.com/i/web/status/1793270389541400753"
    }
  },
  {
    "like" : {
      "tweetId" : "1793268600272236673",
      "fullText" : "@freakmnstrnasty @ShamsJorjani @ArrowheadGS Tru. And we are all friends :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1793268600272236673"
    }
  },
  {
    "like" : {
      "tweetId" : "1793269327874887811",
      "fullText" : "@FriztiO @ShamsJorjani @ArrowheadGS Thank you! Yes - He is way more organized than me haha. Now I got to focus on games!! 🤘",
      "expandedUrl" : "https://twitter.com/i/web/status/1793269327874887811"
    }
  },
  {
    "like" : {
      "tweetId" : "1793267752670515575",
      "fullText" : "@Pilestedt @ShamsJorjani @ArrowheadGS You've been amazing as a CEO so far, he has big shoes to fill. But if you chose him then it must be that he has what it takes",
      "expandedUrl" : "https://twitter.com/i/web/status/1793267752670515575"
    }
  },
  {
    "like" : {
      "tweetId" : "1793269058336399856",
      "fullText" : "@Shichiibukaii @ShamsJorjani @ArrowheadGS Thanks, games before... CEOs....? 🤣",
      "expandedUrl" : "https://twitter.com/i/web/status/1793269058336399856"
    }
  },
  {
    "like" : {
      "tweetId" : "1793268453773639955",
      "fullText" : "@Pilestedt @ShamsJorjani @ArrowheadGS When you lower your position (I think?) to be more involved in your game etc - honestly that speaks volumes.",
      "expandedUrl" : "https://twitter.com/i/web/status/1793268453773639955"
    }
  },
  {
    "like" : {
      "tweetId" : "1793267296682520846",
      "fullText" : "Hey everyone,\n\nBig update, I've decided to hire @ShamsJorjani as the new CEO of @ArrowheadGS! We go way back and I wouldn't trust the business in any other hands than his. (...and he comes with an impressive resume and love for games)\n\nBut what about me and my involvement in…",
      "expandedUrl" : "https://twitter.com/i/web/status/1793267296682520846"
    }
  },
  {
    "like" : {
      "tweetId" : "1792208591442825268",
      "fullText" : "Mario Builder 64 has been released. Much time and effort was poured into this project and I couldn't be happier to share it with all of you. Have fun! 😁 https://t.co/vRiubA0PFZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1792208591442825268"
    }
  },
  {
    "like" : {
      "tweetId" : "1787236790211879269",
      "fullText" : "What's next? Review bombing Magicka and Gauntlet as well? Other PlayStation titles?",
      "expandedUrl" : "https://twitter.com/i/web/status/1787236790211879269"
    }
  },
  {
    "like" : {
      "tweetId" : "1787234494493130925",
      "fullText" : "It deeply saddens me that @HelldiversGame is also being review bombed due to the recent @helldivers2 controversy.",
      "expandedUrl" : "https://twitter.com/i/web/status/1787234494493130925"
    }
  },
  {
    "like" : {
      "tweetId" : "1787253848148455838",
      "fullText" : "The original post was about Helldivers 1 - which is unrelated to the situation with HD2. HD1 does not have PSN login.\n\nSo, it doesn't make sense for people to target unrelated titles. This is about Helldivers 2 and the PSN linking policy.",
      "expandedUrl" : "https://twitter.com/i/web/status/1787253848148455838"
    }
  },
  {
    "like" : {
      "tweetId" : "1787497470563356849",
      "fullText" : "@Pilestedt Hope the negativity passes for you and your team. \n\nHowever there needs to be some major changes with your CM team. They made the situation A LOT worse then it needed to be. \n\nThey are still poking the bear on the discord as we speak with passive aggressive posts.",
      "expandedUrl" : "https://twitter.com/i/web/status/1787497470563356849"
    }
  },
  {
    "like" : {
      "tweetId" : "1787879205763531106",
      "fullText" : "I don't understand the closure of @TangoGameworks, I mean... Why close instead of divest? Surely the team would easily have been able to find a new home. 🤷‍♂️",
      "expandedUrl" : "https://twitter.com/i/web/status/1787879205763531106"
    }
  },
  {
    "like" : {
      "tweetId" : "1788984277113221122",
      "fullText" : "@PirateSoftware I was mocked because I said is in breach of EU privacy and consumer laws.. Those 3 countries are in EU.\n\nSony didn't backed because of players stance but because of unaccounted laws and enough attention to summon investigations.\n\nI stand by my words.",
      "expandedUrl" : "https://twitter.com/i/web/status/1788984277113221122"
    }
  },
  {
    "like" : {
      "tweetId" : "1788308683086057785",
      "fullText" : "@Pilestedt @helldivers2 I’d say release it. \n\n1) the fact you’re posting this and concerned about this shows how much the devs care about the community. \n\n2) it’s not the devs fault all that happened, that was a Sony rule. So don’t punish yourselves.",
      "expandedUrl" : "https://twitter.com/i/web/status/1788308683086057785"
    }
  },
  {
    "like" : {
      "tweetId" : "1788308911101198490",
      "fullText" : "@Pilestedt @helldivers2 Look, if you want this to go well:\n- Release it tomorrow. Delaying it will only generate MORE negative sentiment.\n\n- Next balancing patch should focus on buffs. I understand you cannot do a \"buff only\" balancing style but you need to regain fun, confidence and trust. Focus on the…",
      "expandedUrl" : "https://twitter.com/i/web/status/1788308911101198490"
    }
  },
  {
    "like" : {
      "tweetId" : "1783618826057183476",
      "fullText" : "@helldivers2 Now do i believe this or do i go check personally how my girl eagle 1 is doing?",
      "expandedUrl" : "https://twitter.com/i/web/status/1783618826057183476"
    }
  },
  {
    "like" : {
      "tweetId" : "1783618077218730277",
      "fullText" : "@helldivers2 Wait a minute this is the official Helldivers account. This is what the Eagle-1 Pilot actually looks like, canonically?\n\noh no",
      "expandedUrl" : "https://twitter.com/i/web/status/1783618077218730277"
    }
  },
  {
    "like" : {
      "tweetId" : "1783609674576666958",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1783609674576666958"
    }
  },
  {
    "like" : {
      "tweetId" : "1783608216229761111",
      "fullText" : "@helldivers2 I’d like to report that a friend of mine suggested we start using automated robots to collect E-710. https://t.co/Rq7lWBJLfn",
      "expandedUrl" : "https://twitter.com/i/web/status/1783608216229761111"
    }
  },
  {
    "like" : {
      "tweetId" : "1783607755485360461",
      "fullText" : "SE High Command would like to dispel any rumours that our Eagle pilots have been physically augmented to better perform their duty. \n\nIf you see any personnel with unauthorized body modifications, they may be an Automaton dissident. Stay vigilant, Helldivers.\n\n📎: magisterium_art https://t.co/gzC5QIm29U",
      "expandedUrl" : "https://twitter.com/i/web/status/1783607755485360461"
    }
  },
  {
    "like" : {
      "tweetId" : "1771188065203110121",
      "fullText" : "@bukimi397 Same energy: https://t.co/6yCrpwI7vv",
      "expandedUrl" : "https://twitter.com/i/web/status/1771188065203110121"
    }
  },
  {
    "like" : {
      "tweetId" : "1771181101995770281",
      "fullText" : "ひーろーしぐさ https://t.co/aQUXaoXJ6E",
      "expandedUrl" : "https://twitter.com/i/web/status/1771181101995770281"
    }
  },
  {
    "like" : {
      "tweetId" : "1771550730802913710",
      "fullText" : "ひーろーしぐさ https://t.co/BIheNnPKwR",
      "expandedUrl" : "https://twitter.com/i/web/status/1771550730802913710"
    }
  },
  {
    "like" : {
      "tweetId" : "1772239679380947415",
      "fullText" : "ひーろーしぐさ https://t.co/MeI7hHWU0F",
      "expandedUrl" : "https://twitter.com/i/web/status/1772239679380947415"
    }
  },
  {
    "like" : {
      "tweetId" : "1774825986452046292",
      "fullText" : "ひーろーしぐさ https://t.co/I5ARrKpygU",
      "expandedUrl" : "https://twitter.com/i/web/status/1774825986452046292"
    }
  },
  {
    "like" : {
      "tweetId" : "1775492035748974662",
      "fullText" : "ひーろーしぐさ https://t.co/mQjeSjHhYk",
      "expandedUrl" : "https://twitter.com/i/web/status/1775492035748974662"
    }
  },
  {
    "like" : {
      "tweetId" : "1776574237278449846",
      "fullText" : "ひーろーしぐさ https://t.co/OnMEc4TUOB",
      "expandedUrl" : "https://twitter.com/i/web/status/1776574237278449846"
    }
  },
  {
    "like" : {
      "tweetId" : "1783512019171180630",
      "fullText" : "This is Managed Democracy manifest:\n\n⬇️⬆️⬆️⬅️➡️\nor\n⬇️⬅️⬆️⬆️ https://t.co/PuwssVwlhe",
      "expandedUrl" : "https://twitter.com/i/web/status/1783512019171180630"
    }
  },
  {
    "like" : {
      "tweetId" : "1776013067907744019",
      "fullText" : "When life gives you lemons, make juice https://t.co/SyJQXaGdHA",
      "expandedUrl" : "https://twitter.com/i/web/status/1776013067907744019"
    }
  },
  {
    "like" : {
      "tweetId" : "1766483370798653705",
      "fullText" : "this was about to be a Le sad for not being popular comic, but I just ended up drawing more cats https://t.co/j7PYddOUqb",
      "expandedUrl" : "https://twitter.com/i/web/status/1766483370798653705"
    }
  },
  {
    "like" : {
      "tweetId" : "1771175042040160504",
      "fullText" : "2 out of 3 watermelons are either shot or cut by weapon enthusiasts.\n\nIt's time to stop this cycle of violence. https://t.co/1GL26AXHUW",
      "expandedUrl" : "https://twitter.com/i/web/status/1771175042040160504"
    }
  },
  {
    "like" : {
      "tweetId" : "1773726811806904712",
      "fullText" : "researching Feng Shui has me convinced someone just wanted to justify their BS job https://t.co/QosaU4HeXm",
      "expandedUrl" : "https://twitter.com/i/web/status/1773726811806904712"
    }
  },
  {
    "like" : {
      "tweetId" : "1775062963030044839",
      "fullText" : "Sorry I misspelled bread https://t.co/1Ard2NwSW5 https://t.co/X7HLqi4V4P",
      "expandedUrl" : "https://twitter.com/i/web/status/1775062963030044839"
    }
  },
  {
    "like" : {
      "tweetId" : "1741446723229331713",
      "fullText" : "HAPPY NEW YEAR PARTY !!!🎇🎇🎇\n\nA compilation of artists / characters I enjoyed this year\n\nI'm so happy I finally get to post this after working on it\nThank you all for being a part of my year\n(I'm sorry if I missed any, ill try again next year) https://t.co/C5kG7CvkIi",
      "expandedUrl" : "https://twitter.com/i/web/status/1741446723229331713"
    }
  },
  {
    "like" : {
      "tweetId" : "1774873183583146443",
      "fullText" : "@SEGA We would absolutely sell this if it were real.",
      "expandedUrl" : "https://twitter.com/i/web/status/1774873183583146443"
    }
  },
  {
    "like" : {
      "tweetId" : "1774844639792550007",
      "fullText" : "Releasing with Big Head Mode and Sonic the Hedge cartridges to enhance your Sonic the Hedgehog™ experience.\n\nEach cartridge sold separately. https://t.co/JGOM9gmkEv",
      "expandedUrl" : "https://twitter.com/i/web/status/1774844639792550007"
    }
  },
  {
    "like" : {
      "tweetId" : "1774844250976309518",
      "fullText" : "We’re excited to introduce the next innovation in gaming… Cartridge Loadable Content!\n\nLock-on technology was just the beginning. Insert a second, third, FOURTH cartridge to load new features like never before. Visit your local Blockbuster on April 1st, 1991 to check it out! https://t.co/B1GIeMaLth",
      "expandedUrl" : "https://twitter.com/i/web/status/1774844250976309518"
    }
  },
  {
    "like" : {
      "tweetId" : "1773031980768067721",
      "fullText" : "🌟10万人＆最終話記念スマホ壁紙🌟\n\nTVアニメ「#魔法少女にあこがれて」\n\nフォロワー数10万人＆最終話を記念して\n本編に登場したうてなのスマホ壁紙をプレゼント🌟\nスマホの壁紙に設定していつでも #まほあこ と一緒にお過ごしくださいね🌟\n#まほあこアニメ \n\n▼是非ご使用ください▼ https://t.co/LMS3tiaKgr",
      "expandedUrl" : "https://twitter.com/i/web/status/1773031980768067721"
    }
  },
  {
    "like" : {
      "tweetId" : "1766917886323445914",
      "fullText" : "I just wanted to redraw this scene from looking up to magical girls.\n\nI appreciate the additions in the anime but the manga just hits harder https://t.co/Xbvr4drx8n",
      "expandedUrl" : "https://twitter.com/i/web/status/1766917886323445914"
    }
  },
  {
    "like" : {
      "tweetId" : "1760074209022369976",
      "fullText" : "This is the most insane game I have ever seen. Please watch until 23 seconds https://t.co/5LLJWe2D3Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1760074209022369976"
    }
  },
  {
    "like" : {
      "tweetId" : "1733101621247430838",
      "fullText" : "And if french coffee is not your thing, you can also try latte☕️🥛 https://t.co/oTbarwE8bq https://t.co/PeBXWsM2Vt",
      "expandedUrl" : "https://twitter.com/i/web/status/1733101621247430838"
    }
  },
  {
    "like" : {
      "tweetId" : "1734229680310583391",
      "fullText" : "Evocatus is my funniest soldier https://t.co/lqoWZKzg8y",
      "expandedUrl" : "https://twitter.com/i/web/status/1734229680310583391"
    }
  },
  {
    "like" : {
      "tweetId" : "1736133254862803139",
      "fullText" : "I needed more roman figures @CenturiiC https://t.co/8DHyAPlVnB",
      "expandedUrl" : "https://twitter.com/i/web/status/1736133254862803139"
    }
  },
  {
    "like" : {
      "tweetId" : "1736747771087262048",
      "fullText" : "evocatus, my silliest soldier https://t.co/J5KL82nRjW",
      "expandedUrl" : "https://twitter.com/i/web/status/1736747771087262048"
    }
  },
  {
    "like" : {
      "tweetId" : "1736057291093463123",
      "fullText" : "@losenis I draw bigger tits for bigger rank.\n\nactually hoped ppl would eventually notice",
      "expandedUrl" : "https://twitter.com/i/web/status/1736057291093463123"
    }
  },
  {
    "like" : {
      "tweetId" : "1736041419905847314",
      "fullText" : "Centurii if she ever got her promotion https://t.co/TKKTlDUj8h",
      "expandedUrl" : "https://twitter.com/i/web/status/1736041419905847314"
    }
  },
  {
    "like" : {
      "tweetId" : "1731813645607170438",
      "fullText" : "@RockstarGames OFFICIAL LOGO https://t.co/Mveq92E7l0",
      "expandedUrl" : "https://twitter.com/i/web/status/1731813645607170438"
    }
  },
  {
    "like" : {
      "tweetId" : "1731814400338886990",
      "fullText" : "@RockstarGames playboi carti take notes",
      "expandedUrl" : "https://twitter.com/i/web/status/1731814400338886990"
    }
  },
  {
    "like" : {
      "tweetId" : "1731813983546376650",
      "fullText" : "@RockstarGames Was NOT expecting this tweet lmao",
      "expandedUrl" : "https://twitter.com/i/web/status/1731813983546376650"
    }
  },
  {
    "like" : {
      "tweetId" : "1731814190363361390",
      "fullText" : "@RockstarGames 2025.. what will we do till then",
      "expandedUrl" : "https://twitter.com/i/web/status/1731814190363361390"
    }
  },
  {
    "like" : {
      "tweetId" : "1731814782972432759",
      "fullText" : "@RockstarGames Someone leak the game next so they release it early too",
      "expandedUrl" : "https://twitter.com/i/web/status/1731814782972432759"
    }
  },
  {
    "like" : {
      "tweetId" : "1731813331244085531",
      "fullText" : "Our trailer has leaked so please watch the real thing on YouTube: https://t.co/T0QOBDHwBe",
      "expandedUrl" : "https://twitter.com/i/web/status/1731813331244085531"
    }
  },
  {
    "like" : {
      "tweetId" : "1719832383094935784",
      "fullText" : "Announcing: Savant x Owlboy! \n\nPlay as Team Otus 🦉 in the upcoming DLC to Savant - Ascent REMIX. Available Dec 5th!\n\n#owlboy #savant #indiegame #wishlistwednesday https://t.co/vbQmp9itOJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1719832383094935784"
    }
  },
  {
    "like" : {
      "tweetId" : "1714402698001363427",
      "fullText" : "The actions-rs org just got archived!\n\nFor a maintained set of actions with an easy upgrade path, try actions-rust-lang/setup-rust-toolchain.\n\nFull disclosure: I help maintain this org.\n\nhttps://t.co/AL7vIIloZA",
      "expandedUrl" : "https://twitter.com/i/web/status/1714402698001363427"
    }
  },
  {
    "like" : {
      "tweetId" : "1714657801023127604",
      "fullText" : "@Tony_Barotsis It’s pretty similar but includes pre-configured caching by default so you don’t need to know the incantation and duplicate it throughout your workflows.",
      "expandedUrl" : "https://twitter.com/i/web/status/1714657801023127604"
    }
  },
  {
    "like" : {
      "tweetId" : "1719262178841133492",
      "fullText" : "IT’S MEME TIME!\n@LizzieRFreeman and I decided to give this a shot for ourselves!\n\nCredit goes to @DeputyRustArt for the original comic, @KHtheKARTOONiST for the animation, and @kovox for mixing! https://t.co/0aGnXWG33y https://t.co/JQFzdZBc0u",
      "expandedUrl" : "https://twitter.com/i/web/status/1719262178841133492"
    }
  },
  {
    "like" : {
      "tweetId" : "1699798357269753980",
      "fullText" : "BIG https://t.co/f6jBdoOZjW",
      "expandedUrl" : "https://twitter.com/i/web/status/1699798357269753980"
    }
  },
  {
    "like" : {
      "tweetId" : "1701251446941835328",
      "fullText" : "oh no.. dog is getting even bigger !!!\nD: !!! https://t.co/C7F8Q3V0Kh",
      "expandedUrl" : "https://twitter.com/i/web/status/1701251446941835328"
    }
  },
  {
    "like" : {
      "tweetId" : "1695018776008237280",
      "fullText" : "@CrazyItalianPol degna di nota la scelta di mettere Torino e non cagare Milano.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695018776008237280"
    }
  },
  {
    "like" : {
      "tweetId" : "1694852520756036018",
      "fullText" : "@CrazyItalianPol Un paese in guerra che ironizza sui commenti dei nazifood italiani sotto i video degli americani. Che tempi meravigliosi.",
      "expandedUrl" : "https://twitter.com/i/web/status/1694852520756036018"
    }
  },
  {
    "like" : {
      "tweetId" : "1694795992321696074",
      "fullText" : "@DefenceU This &gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Open to meraviglia",
      "expandedUrl" : "https://twitter.com/i/web/status/1694795992321696074"
    }
  },
  {
    "like" : {
      "tweetId" : "1694615524960080138",
      "fullText" : "Thank you, Italy 🇺🇦🤝🇮🇹\n\n#UkraineSaysThankYou\n#UkraineIndependenceDay https://t.co/AbOlkGlanx",
      "expandedUrl" : "https://twitter.com/i/web/status/1694615524960080138"
    }
  },
  {
    "like" : {
      "tweetId" : "1694843404687913090",
      "fullText" : "That crazy moment when another country produces a better ad for our tourism than our Ministry of Tourism. https://t.co/6Lsw8o3j3p",
      "expandedUrl" : "https://twitter.com/i/web/status/1694843404687913090"
    }
  },
  {
    "like" : {
      "tweetId" : "1683361219561000960",
      "fullText" : "@CrazyItalianPol Way better than fascist memorabilia if you ask me",
      "expandedUrl" : "https://twitter.com/i/web/status/1683361219561000960"
    }
  },
  {
    "like" : {
      "tweetId" : "1683233107187576832",
      "fullText" : "The Italian policeman with the Lupin III action figures in his office. Now we've seen them all. https://t.co/cVCanZDWnz",
      "expandedUrl" : "https://twitter.com/i/web/status/1683233107187576832"
    }
  },
  {
    "like" : {
      "tweetId" : "1672679134336626693",
      "fullText" : "Thanks to #Belarus’ President #Lukashenko boys can have some sleep now too 😉 @elonmusk https://t.co/14jIw8voBe",
      "expandedUrl" : "https://twitter.com/i/web/status/1672679134336626693"
    }
  },
  {
    "like" : {
      "tweetId" : "1673012054993649667",
      "fullText" : "yevgeny what’s going on💀 https://t.co/jJinEEWhwk",
      "expandedUrl" : "https://twitter.com/i/web/status/1673012054993649667"
    }
  },
  {
    "like" : {
      "tweetId" : "1671529316616740867",
      "fullText" : "This study led by University of Central Florida found that Attention Deficit Hyperactivity Disorder symptoms manifest watching videos requiring executive brain function \n\n[read more: https://t.co/bmhOiynRaQ]\n[full paper: https://t.co/ZY0KngECRY]\nhttps://t.co/lNJgpbuuhH",
      "expandedUrl" : "https://twitter.com/i/web/status/1671529316616740867"
    }
  },
  {
    "like" : {
      "tweetId" : "1671576191571210240",
      "fullText" : "ok but clearly they need better math videos https://t.co/JXx33Z8Yjq",
      "expandedUrl" : "https://twitter.com/i/web/status/1671576191571210240"
    }
  },
  {
    "like" : {
      "tweetId" : "1669095113367142402",
      "fullText" : "il devasto nella diretta instagram di Emilio Fede https://t.co/l8xz6cY4Ku",
      "expandedUrl" : "https://twitter.com/i/web/status/1669095113367142402"
    }
  },
  {
    "like" : {
      "tweetId" : "1658461768254119936",
      "fullText" : "🍿 De-aging Harrison Ford with Stable Diffusion 🍿\n\nSD deepfakes = \"the next autotune of the entertainment industry\" https://t.co/Ei8MB2JWcy",
      "expandedUrl" : "https://twitter.com/i/web/status/1658461768254119936"
    }
  },
  {
    "like" : {
      "tweetId" : "1665874109111185408",
      "fullText" : "https://t.co/R9YyQvqebu",
      "expandedUrl" : "https://twitter.com/i/web/status/1665874109111185408"
    }
  },
  {
    "like" : {
      "tweetId" : "1565599597082312705",
      "fullText" : "\"Jeflon Zuckergates\"\n\n#StableDiffusion #AIArt #AIArtwork #DreamStudio @StableDiffusion https://t.co/OdEg0LKEAd",
      "expandedUrl" : "https://twitter.com/i/web/status/1565599597082312705"
    }
  },
  {
    "like" : {
      "tweetId" : "1620803351221862400",
      "fullText" : "Soyjak vs Chad #AIArt\n\n#StableDiffusion2 / #StableDiffusion  #DreamStudio https://t.co/ngo5HlR2KY",
      "expandedUrl" : "https://twitter.com/i/web/status/1620803351221862400"
    }
  },
  {
    "like" : {
      "tweetId" : "1664588883227557894",
      "fullText" : "Mayor of Asti https://t.co/vAI4bD5NCH",
      "expandedUrl" : "https://twitter.com/i/web/status/1664588883227557894"
    }
  },
  {
    "like" : {
      "tweetId" : "1598108955137703937",
      "fullText" : "The buff bunny girl https://t.co/KSGLGwGy4a",
      "expandedUrl" : "https://twitter.com/i/web/status/1598108955137703937"
    }
  },
  {
    "like" : {
      "tweetId" : "1637626993222230016",
      "fullText" : "Probably one of these https://t.co/4awA5dXZDw https://t.co/W0Fq5NtOZB",
      "expandedUrl" : "https://twitter.com/i/web/status/1637626993222230016"
    }
  },
  {
    "like" : {
      "tweetId" : "1656492034616856576",
      "fullText" : "I'll even post it on main https://t.co/zOIYhZ3hyY",
      "expandedUrl" : "https://twitter.com/i/web/status/1656492034616856576"
    }
  },
  {
    "like" : {
      "tweetId" : "1656807635474341889",
      "fullText" : "X-ray activate! https://t.co/klEPuM5eoo",
      "expandedUrl" : "https://twitter.com/i/web/status/1656807635474341889"
    }
  },
  {
    "like" : {
      "tweetId" : "1657544566919286784",
      "fullText" : "Goal set higher than I think it'll go cause I wanna play the game, but if people really want it, I'll muster up more will power to pry myself away from my switch, lol https://t.co/H01KDRXuHv",
      "expandedUrl" : "https://twitter.com/i/web/status/1657544566919286784"
    }
  },
  {
    "like" : {
      "tweetId" : "1662266258530893824",
      "fullText" : "Melty Zero Suit https://t.co/jNwmes1oSM",
      "expandedUrl" : "https://twitter.com/i/web/status/1662266258530893824"
    }
  },
  {
    "like" : {
      "tweetId" : "1653118947997130756",
      "fullText" : "AI has made a Star Wars reboot (directed by Wes Anderson) https://t.co/bRON9Nu3y7",
      "expandedUrl" : "https://twitter.com/i/web/status/1653118947997130756"
    }
  },
  {
    "like" : {
      "tweetId" : "986718252167413760",
      "fullText" : "According to this wonderful figure, impact force of projectile Brachiosaurus vomit is then roughly equivalent to bite force of T. rex. How amazing is that!? https://t.co/ftx3Q5EziR",
      "expandedUrl" : "https://twitter.com/i/web/status/986718252167413760"
    }
  },
  {
    "like" : {
      "tweetId" : "1632896738657959937",
      "fullText" : "\"Meet the Engineer\" over the years https://t.co/WpeHNEgzev",
      "expandedUrl" : "https://twitter.com/i/web/status/1632896738657959937"
    }
  },
  {
    "like" : {
      "tweetId" : "1539242791687049218",
      "fullText" : "Dwarven runes are very \"versatile\" https://t.co/WjuwP2UKZN",
      "expandedUrl" : "https://twitter.com/i/web/status/1539242791687049218"
    }
  },
  {
    "like" : {
      "tweetId" : "1544402084010737664",
      "fullText" : "Heard you all have been having fun with our big new update, so we decided it's time to make it even better! v3.0.1 is already here, bringing with it lots of additional features, changes, and fixes! 🎵✨\n\nCheck out the patch notes here: https://t.co/CXepfQY8K1 https://t.co/3UKknzEiGz",
      "expandedUrl" : "https://twitter.com/i/web/status/1544402084010737664"
    }
  },
  {
    "like" : {
      "tweetId" : "1555240899088592896",
      "fullText" : "RE-ANIMATE!!! 💀✨\n\nAfter 5 long years we're back from the dead with a huge new DLC – Crypt of the NecroDancer: SYNCHRONY, featuring:\n\n👥 Online multiplayer!\n😈 3 new characters!\n🔧 Full mod support!\n👻 New items, enemies &amp; more!\n\nGet Early Access now ➡️ https://t.co/mrlhPqtyPI https://t.co/Zb92qf6Xt4",
      "expandedUrl" : "https://twitter.com/i/web/status/1555240899088592896"
    }
  },
  {
    "like" : {
      "tweetId" : "1557048297659183104",
      "fullText" : "Cadence and Chaunter https://t.co/5CT0m11Kk8",
      "expandedUrl" : "https://twitter.com/i/web/status/1557048297659183104"
    }
  },
  {
    "like" : {
      "tweetId" : "1559350555943653376",
      "fullText" : "LOVE all the #Necrodancer Synchrony fanart! Here's some weekend doodles for ya'll ❤️ https://t.co/SysIN7ZyS5",
      "expandedUrl" : "https://twitter.com/i/web/status/1559350555943653376"
    }
  },
  {
    "like" : {
      "tweetId" : "1562559981320167425",
      "fullText" : "OPEN THE RIFT!!! #NecroDancer https://t.co/ZalxUAI9WK https://t.co/hEim5LqvdP",
      "expandedUrl" : "https://twitter.com/i/web/status/1562559981320167425"
    }
  },
  {
    "like" : {
      "tweetId" : "1556869648217698304",
      "fullText" : "multiplay experience #NecroDancer https://t.co/duZNTf9j3C",
      "expandedUrl" : "https://twitter.com/i/web/status/1556869648217698304"
    }
  },
  {
    "like" : {
      "tweetId" : "1562940173947895808",
      "fullText" : "By popular demand, here is the full art for modern Cadence and Dove! https://t.co/tzCnrmQO4T",
      "expandedUrl" : "https://twitter.com/i/web/status/1562940173947895808"
    }
  },
  {
    "like" : {
      "tweetId" : "1563204384015908865",
      "fullText" : "ok just for u https://t.co/TCJW2TUuho https://t.co/4mWmtpuqKY",
      "expandedUrl" : "https://twitter.com/i/web/status/1563204384015908865"
    }
  },
  {
    "like" : {
      "tweetId" : "1565108967973470210",
      "fullText" : "OK FINE y’all can have Nocturna too https://t.co/bpJXkDUCHd https://t.co/3TTqt7ayMZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1565108967973470210"
    }
  },
  {
    "like" : {
      "tweetId" : "1570011638236938246",
      "fullText" : "Zone 3\n#NecroDancer https://t.co/bGsy6IEtfJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1570011638236938246"
    }
  },
  {
    "like" : {
      "tweetId" : "1571860167192616962",
      "fullText" : "Hyped for Rift of the Necrodancer so I made some Cadence fanart 😬 can't wait to play this one!\n#NecroDancer @NecroDancerGame https://t.co/ahQGA4zcp8",
      "expandedUrl" : "https://twitter.com/i/web/status/1571860167192616962"
    }
  },
  {
    "like" : {
      "tweetId" : "1572364715279650816",
      "fullText" : "\"Graphics are the first thing finished in a video game\"\n\nHere’s what an early iteration of Rift of the NecroDancer’s yoga minigame looked like https://t.co/U8O42YrV0n",
      "expandedUrl" : "https://twitter.com/i/web/status/1572364715279650816"
    }
  },
  {
    "like" : {
      "tweetId" : "1574513001180594176",
      "fullText" : "eyes for among us only https://t.co/KU3E7HdUZf https://t.co/wxiRZxEeqe",
      "expandedUrl" : "https://twitter.com/i/web/status/1574513001180594176"
    }
  },
  {
    "like" : {
      "tweetId" : "1583475115198906368",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1583475115198906368"
    }
  },
  {
    "like" : {
      "tweetId" : "1586779972345024512",
      "fullText" : "Who's winning in Trick or Treat mode? https://t.co/fTBEyvrBYb",
      "expandedUrl" : "https://twitter.com/i/web/status/1586779972345024512"
    }
  },
  {
    "like" : {
      "tweetId" : "1618408761315700737",
      "fullText" : "Here's some early exploration of Rift Cadence (and a Dove)! https://t.co/DWHgfAU9RT https://t.co/XA5MrlWFq1",
      "expandedUrl" : "https://twitter.com/i/web/status/1618408761315700737"
    }
  },
  {
    "like" : {
      "tweetId" : "1618414194214465538",
      "fullText" : "Here's a couple more early designs of Cadence when we thought she might wear a hat 🧢 https://t.co/DWHgfAU9RT https://t.co/isNVcvc3hQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1618414194214465538"
    }
  },
  {
    "like" : {
      "tweetId" : "1618415658747953154",
      "fullText" : "Because Rift takes place in the modern world, a big part of the design was about keeping the character's essence while overhauling their look to represent more personality.\n\nWhat do they do? What are their hobbies? What is their personal style?\n\nAND NO MORE TUNICS! ❌❌❌ https://t.co/nT8MhiKoNC https://t.co/UBuckRU4qI",
      "expandedUrl" : "https://twitter.com/i/web/status/1618415658747953154"
    }
  },
  {
    "like" : {
      "tweetId" : "1625696498078867456",
      "fullText" : "Voltage glitching attack illustrated https://t.co/CDvj7Dq4vX",
      "expandedUrl" : "https://twitter.com/i/web/status/1625696498078867456"
    }
  },
  {
    "like" : {
      "tweetId" : "1575167584923549706",
      "fullText" : "fun game :D\n#CryptOfTheNecrodancer @NecroDancerGame https://t.co/kKI5X8nXvr",
      "expandedUrl" : "https://twitter.com/i/web/status/1575167584923549706"
    }
  },
  {
    "like" : {
      "tweetId" : "1618647500755460096",
      "fullText" : "I don't know man this cannot be that good for you https://t.co/XbP8bzlal9",
      "expandedUrl" : "https://twitter.com/i/web/status/1618647500755460096"
    }
  },
  {
    "like" : {
      "tweetId" : "1616389280540119041",
      "fullText" : "incredible how the french have truly *perfected* the art of striking https://t.co/xtk4qIY3gd",
      "expandedUrl" : "https://twitter.com/i/web/status/1616389280540119041"
    }
  },
  {
    "like" : {
      "tweetId" : "1616094597507080192",
      "fullText" : "I was born to work retail (1/3) https://t.co/WhliZ4Wld9",
      "expandedUrl" : "https://twitter.com/i/web/status/1616094597507080192"
    }
  },
  {
    "like" : {
      "tweetId" : "1616069930549493765",
      "fullText" : "Da @joinmastodon :)\n\n#bidellapendolare https://t.co/dOQoVWAW2s",
      "expandedUrl" : "https://twitter.com/i/web/status/1616069930549493765"
    }
  },
  {
    "like" : {
      "tweetId" : "992097650043334656",
      "fullText" : "I couldn't see it, too dark outside, but a wave of heat just came over me. Feels like the temperature increased by like 10 or 15 degrees.",
      "expandedUrl" : "https://twitter.com/i/web/status/992097650043334656"
    }
  },
  {
    "like" : {
      "tweetId" : "990944897392889857",
      "fullText" : "Help.",
      "expandedUrl" : "https://twitter.com/i/web/status/990944897392889857"
    }
  },
  {
    "like" : {
      "tweetId" : "1611867781305098242",
      "fullText" : ".. https://t.co/BfU3TdwV08",
      "expandedUrl" : "https://twitter.com/i/web/status/1611867781305098242"
    }
  },
  {
    "like" : {
      "tweetId" : "1597095214925348866",
      "fullText" : "Bffs💖💖 https://t.co/2cjiERm03t",
      "expandedUrl" : "https://twitter.com/i/web/status/1597095214925348866"
    }
  },
  {
    "like" : {
      "tweetId" : "1596925166381985794",
      "fullText" : "The new Call of Duty physics got us distracted… 😅 https://t.co/HQFc8r3SvO",
      "expandedUrl" : "https://twitter.com/i/web/status/1596925166381985794"
    }
  },
  {
    "like" : {
      "tweetId" : "1579227116897415168",
      "fullText" : "Voron Delta when? https://t.co/Go4e3xV1xT",
      "expandedUrl" : "https://twitter.com/i/web/status/1579227116897415168"
    }
  },
  {
    "like" : {
      "tweetId" : "1516747750729265159",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1516747750729265159"
    }
  },
  {
    "like" : {
      "tweetId" : "1465071198623215623",
      "fullText" : "@avis_fvg Super carina 🥰 https://t.co/AFF6YZkkPq",
      "expandedUrl" : "https://twitter.com/i/web/status/1465071198623215623"
    }
  },
  {
    "like" : {
      "tweetId" : "1464638778069471237",
      "fullText" : "@avis_fvg Tieni tutto il mio sangue.",
      "expandedUrl" : "https://twitter.com/i/web/status/1464638778069471237"
    }
  },
  {
    "like" : {
      "tweetId" : "1464668259433787397",
      "fullText" : "@avis_fvg Simp&gt;&gt;&gt;&gt;sensibilizzazione.\n\nEccellente mossa, sostengo in pieno ✨",
      "expandedUrl" : "https://twitter.com/i/web/status/1464668259433787397"
    }
  },
  {
    "like" : {
      "tweetId" : "1433692817386266630",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1433692817386266630"
    }
  },
  {
    "like" : {
      "tweetId" : "1592667572410798081",
      "fullText" : "lil mama was rolling like that can of campbells soup on that one commercial https://t.co/Wy9PEZRnnt",
      "expandedUrl" : "https://twitter.com/i/web/status/1592667572410798081"
    }
  },
  {
    "like" : {
      "tweetId" : "1590854364515950592",
      "fullText" : "@wartranslated https://t.co/UzsD1tuSF8",
      "expandedUrl" : "https://twitter.com/i/web/status/1590854364515950592"
    }
  },
  {
    "like" : {
      "tweetId" : "1590746768362606593",
      "fullText" : "@Prune602 @francis_scarr That man is a Living Breathing Meme Machine!!! https://t.co/Wm5LlkTYFJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1590746768362606593"
    }
  },
  {
    "like" : {
      "tweetId" : "1590851658023849985",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1590851658023849985"
    }
  },
  {
    "like" : {
      "tweetId" : "1590852410435842048",
      "fullText" : "@wartranslated So in other words, he’s not allowed an opinion.",
      "expandedUrl" : "https://twitter.com/i/web/status/1590852410435842048"
    }
  },
  {
    "like" : {
      "tweetId" : "1590851151679074306",
      "fullText" : "This Russian TV presenter is worried about expressing his inion on the Kherson withdrawal. Reason? He'd go to prison in any case. https://t.co/lwaem3kEVr",
      "expandedUrl" : "https://twitter.com/i/web/status/1590851151679074306"
    }
  },
  {
    "like" : {
      "tweetId" : "1589755576577413120",
      "fullText" : "0.3スーツ https://t.co/nJd16woMRA",
      "expandedUrl" : "https://twitter.com/i/web/status/1589755576577413120"
    }
  },
  {
    "like" : {
      "tweetId" : "1581877127405715456",
      "fullText" : "I’ve been watching all of the Japanese “the foreigners are back” news segments and there have been some great moments. This one is the best tho 😂 https://t.co/AM6Y2IyBI7",
      "expandedUrl" : "https://twitter.com/i/web/status/1581877127405715456"
    }
  },
  {
    "like" : {
      "tweetId" : "1578304990334005248",
      "fullText" : "He received the ballot papers 12 days after the elections are over https://t.co/r1tuiku7Ku",
      "expandedUrl" : "https://twitter.com/i/web/status/1578304990334005248"
    }
  },
  {
    "like" : {
      "tweetId" : "1580480505409331200",
      "fullText" : "@CrazyItalianPol @lorepregliasco I dati della foto pubblicati da Wikipedia dicono 2005 ahah\nhttps://t.co/cTkKIwpQP2 https://t.co/jRZIbD5Rp7",
      "expandedUrl" : "https://twitter.com/i/web/status/1580480505409331200"
    }
  },
  {
    "like" : {
      "tweetId" : "1580565053161762816",
      "fullText" : "La Russa 🧡 MILFs\n#LaRussa #IgnazioLaRussa https://t.co/xvubaWNgLv https://t.co/U8XxHRyLqO",
      "expandedUrl" : "https://twitter.com/i/web/status/1580565053161762816"
    }
  },
  {
    "like" : {
      "tweetId" : "1580581775310749697",
      "fullText" : "Silvio taking the wrong exit https://t.co/5XW8MezCtp",
      "expandedUrl" : "https://twitter.com/i/web/status/1580581775310749697"
    }
  },
  {
    "like" : {
      "tweetId" : "1578246518141640704",
      "fullText" : "Ma chi l'avrebbe mai detto.\nArrivato oggi. \nUn Paese incredibile 🇮🇹\n#italianelection #ElezioniPolitiche2022 https://t.co/x9x9ZKyS8r",
      "expandedUrl" : "https://twitter.com/i/web/status/1578246518141640704"
    }
  },
  {
    "like" : {
      "tweetId" : "1577988185459662849",
      "fullText" : "Caption this. #Throwback @VancityReynolds https://t.co/k9URIOOdqU",
      "expandedUrl" : "https://twitter.com/i/web/status/1577988185459662849"
    }
  },
  {
    "like" : {
      "tweetId" : "1577538019321585664",
      "fullText" : "@ConnorEatsPants \"What? WHAT DO YOU MEAN ONE MARIO'S DESIGN WAS LEAKED THROUGH A MCDONALDS ADVERTISEMENT?!\" https://t.co/FmS2QJHU5A",
      "expandedUrl" : "https://twitter.com/i/web/status/1577538019321585664"
    }
  },
  {
    "like" : {
      "tweetId" : "1577529389146841088",
      "fullText" : "did a McDonalds employee in the ConnorEatsPants discord just leak the first photo of Mario in the Mario Movie https://t.co/DK7hITeJAP",
      "expandedUrl" : "https://twitter.com/i/web/status/1577529389146841088"
    }
  },
  {
    "like" : {
      "tweetId" : "1576256695742799872",
      "fullText" : "8+ years of Git and a couple times a year I still get into a state where I have to rm -rf and re-clone. For folks just getting started it's not just you we all struggle, this tool sucks. Yes I know about and am comfy with reflog.",
      "expandedUrl" : "https://twitter.com/i/web/status/1576256695742799872"
    }
  },
  {
    "like" : {
      "tweetId" : "1576154252615241728",
      "expandedUrl" : "https://twitter.com/i/web/status/1576154252615241728"
    }
  },
  {
    "like" : {
      "tweetId" : "1575906220220723205",
      "fullText" : "Pretty good demonstration of trickle down economics 😅 https://t.co/XfgLLHArVp",
      "expandedUrl" : "https://twitter.com/i/web/status/1575906220220723205"
    }
  },
  {
    "like" : {
      "tweetId" : "1574813210418581504",
      "fullText" : "JUST PRE-ORDERED MY DREAD SAMUS FIGMA \n\nHere's some of my Dread Suit drawings to celebrate 🤍 https://t.co/ojXzbLzoJ7",
      "expandedUrl" : "https://twitter.com/i/web/status/1574813210418581504"
    }
  },
  {
    "like" : {
      "tweetId" : "1574865217141481477",
      "fullText" : "Hard keeping my mouth sewn shut about this one. ⚔️ https://t.co/OdV7JmAkEu",
      "expandedUrl" : "https://twitter.com/i/web/status/1574865217141481477"
    }
  },
  {
    "like" : {
      "tweetId" : "1572780214114992128",
      "fullText" : "https://t.co/zNrsEIQmRO",
      "expandedUrl" : "https://twitter.com/i/web/status/1572780214114992128"
    }
  },
  {
    "like" : {
      "tweetId" : "1572664724642467841",
      "fullText" : "Time for my daily dose of Samus😏\n\n#Metroid #pixelart https://t.co/uOZMlVxbK1",
      "expandedUrl" : "https://twitter.com/i/web/status/1572664724642467841"
    }
  },
  {
    "like" : {
      "tweetId" : "1569563863456296960",
      "fullText" : "this is the future of esports https://t.co/9IcA6HJDFW",
      "expandedUrl" : "https://twitter.com/i/web/status/1569563863456296960"
    }
  },
  {
    "like" : {
      "tweetId" : "1426559978127642632",
      "fullText" : "And the sun shined on them again\n\n(2/2)\n#Loki #Thor https://t.co/vcb7umCoQL",
      "expandedUrl" : "https://twitter.com/i/web/status/1426559978127642632"
    }
  },
  {
    "like" : {
      "tweetId" : "1426559972616384517",
      "fullText" : "And the sun shined on them again\n\n(1/2)\n#Loki #Thor https://t.co/kPkGemCtpt",
      "expandedUrl" : "https://twitter.com/i/web/status/1426559972616384517"
    }
  },
  {
    "like" : {
      "tweetId" : "1561745020012470273",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1561745020012470273"
    }
  },
  {
    "like" : {
      "tweetId" : "1538899479394279424",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1538899479394279424"
    }
  },
  {
    "like" : {
      "tweetId" : "1314890094243983362",
      "fullText" : "Next up, on Discovery channèl https://t.co/6dfLadKG49",
      "expandedUrl" : "https://twitter.com/i/web/status/1314890094243983362"
    }
  },
  {
    "like" : {
      "tweetId" : "1510423105604227076",
      "fullText" : "@RANK10YGO I can't wait for Morbius 2: More Bius",
      "expandedUrl" : "https://twitter.com/i/web/status/1510423105604227076"
    }
  },
  {
    "like" : {
      "tweetId" : "1510361009621450761",
      "fullText" : "the best part of Morbius was when he said \"IT'S MORBIN' TIME\" and morbed all over those guys",
      "expandedUrl" : "https://twitter.com/i/web/status/1510361009621450761"
    }
  },
  {
    "like" : {
      "tweetId" : "1514357760569323520",
      "fullText" : "In the final days of @BlueSkyStudios, a small team of artists came together to do one final shot. This shot is a farewell, a send-off on our own terms ------ Blue Sky Studios 🌰\n\n#IceAge #IceAgeScratTales\n\nhttps://t.co/CA3klgo98x https://t.co/tkcXwyLcMS",
      "expandedUrl" : "https://twitter.com/i/web/status/1514357760569323520"
    }
  },
  {
    "like" : {
      "tweetId" : "1435302107456933891",
      "fullText" : "[GOOD END] https://t.co/wiULQzFlhY",
      "expandedUrl" : "https://twitter.com/i/web/status/1435302107456933891"
    }
  },
  {
    "like" : {
      "tweetId" : "1484940293870964738",
      "fullText" : "@S20_TBL ☢ \"This is beautiful...\" ☢",
      "expandedUrl" : "https://twitter.com/i/web/status/1484940293870964738"
    }
  },
  {
    "like" : {
      "tweetId" : "1484936632868679681",
      "fullText" : "Facts https://t.co/YtD4bwGelg",
      "expandedUrl" : "https://twitter.com/i/web/status/1484936632868679681"
    }
  },
  {
    "like" : {
      "tweetId" : "1462521008779366403",
      "fullText" : "https://t.co/xI0HTiUsCB",
      "expandedUrl" : "https://twitter.com/i/web/status/1462521008779366403"
    }
  },
  {
    "like" : {
      "tweetId" : "1503353741650665472",
      "fullText" : "@elonmusk Putin rn https://t.co/8wufOeEQ9W",
      "expandedUrl" : "https://twitter.com/i/web/status/1503353741650665472"
    }
  }
]