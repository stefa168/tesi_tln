window.YTD.contact.part0 = [
  {
    "contact" : {
      "emails" : [
        "fradamasio@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393490798801"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393402997209"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393809022561"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "paolo.98.tron@gmail.com"
      ],
      "phoneNumbers" : [
        "+393277312804"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393317998000"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "lorenzov94@yahoo.it"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393662669004"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393485950523"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393479353772"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393459717652"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "davidecosenza98@gmail.com"
      ],
      "phoneNumbers" : [
        "+393661998362"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393341175224"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393408286545"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "ercole.andrea99@hotmail.it"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393342917410"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393394392595"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "maninimirko@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393312578136"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "matt.alasio@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393936759395"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393351491695"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+390141271730"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393343575071"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "leva1998.2@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "letiziachinellato@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393315360075"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393333449755"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "francesca.stobbione@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393939373376"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "davide99c1p8@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+390141938134"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "matteo@alasio.it"
      ],
      "phoneNumbers" : [
        "+393662672212"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393382297105"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393420287891"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "davidecosenza98@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393409805787"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393771784655"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+390141214680"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+390141594905"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "vanessa.rosso58@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393204151229"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393318157426"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393466973271"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "magnifabio98@gmail.com"
      ],
      "phoneNumbers" : [
        "+393336430901"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393338881469"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393336998141"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "porta_a@libero.it"
      ],
      "phoneNumbers" : [
        "+393357506324"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393481361077"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "andreamaths@gmail.com"
      ],
      "phoneNumbers" : [
        "+393393923733"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "umbynos@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "riki.forza5@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393289697931"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "magnifabio98@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393664898730"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "ele.farina@virgilio.it"
      ],
      "phoneNumbers" : [
        "+393477566584"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "vtortoriello98@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393384137446"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "gasparinarianna@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "vt291298@live.it"
      ],
      "phoneNumbers" : [
        "+393928493968"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393337831016"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "paolo.98.tron@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393920895067"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "mariarosafarina@libero.it"
      ],
      "phoneNumbers" : [
        "+393396621079"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "adriparrotta@yahoo.it"
      ],
      "phoneNumbers" : [
        "+393923941419"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "roero.madame@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393451287231"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393772413284"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393341020408"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [ ],
      "phoneNumbers" : [
        "+393468030763"
      ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "wxmenavengers@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  },
  {
    "contact" : {
      "emails" : [
        "simone.fasolis98@gmail.com"
      ],
      "phoneNumbers" : [ ]
    }
  }
]