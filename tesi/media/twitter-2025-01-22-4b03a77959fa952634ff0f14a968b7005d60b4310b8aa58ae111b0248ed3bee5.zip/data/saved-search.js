window.YTD.saved_search.part0 = [
  {
    "savedSearch" : {
      "savedSearchId" : "110336295",
      "query" : "@mojangteam"
    }
  }
]