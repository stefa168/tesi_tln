window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mF39HSf6XFazIQ2A2IGLKVvR88eEt60P9U3WPc30",
      "createdAt" : "2023-10-08T09:57:25.283Z",
      "lastSeenAt" : "2023-10-08T09:57:25.285Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "4PfjO0CBnHHKFcG0Z4UoetoaiFCNROsurRho3GT8",
      "createdAt" : "2024-02-18T21:14:05.751Z",
      "lastSeenAt" : "2024-02-18T21:14:05.753Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mcmuqRV0Bb3oMlgeWyTJJk3hnO6VUt050guozbVt",
      "createdAt" : "2024-03-27T21:30:24.760Z",
      "lastSeenAt" : "2024-03-27T21:30:24.761Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "JlebZZWXimS0GVNZatsLvRtwawMhUCk6WAvzzCu7",
      "createdAt" : "2024-05-08T22:38:06.392Z",
      "lastSeenAt" : "2024-05-08T22:38:06.394Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Gwj2Tl3xGj3ZvYjcBFOcTMIuRKUL3qk127tLu1Rz",
      "createdAt" : "2024-07-11T17:38:47.591Z",
      "lastSeenAt" : "2024-07-11T17:38:47.593Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "G5BJ0k2rHp2uf6YpDeBKRGrOIjPFdKYdlPMhXqJ3",
      "createdAt" : "2024-08-14T22:10:44.005Z",
      "lastSeenAt" : "2024-08-14T22:10:44.007Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "dH7CyDcCoRPJ3J99fXLEWSOb94Vy7jnPLMEiRoGE",
      "createdAt" : "2024-09-17T22:39:15.209Z",
      "lastSeenAt" : "2024-09-17T22:39:15.211Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]