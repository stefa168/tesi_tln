window.YTD.phone_number.part0 = [
  {
    "device" : {
      "phoneNumber" : "+393662846410"
    }
  }
]