window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1228705116125093889",
      "userLink" : "https://twitter.com/intent/user?user_id=1228705116125093889"
    }
  },
  {
    "follower" : {
      "accountId" : "1722265146",
      "userLink" : "https://twitter.com/intent/user?user_id=1722265146"
    }
  },
  {
    "follower" : {
      "accountId" : "1465747711",
      "userLink" : "https://twitter.com/intent/user?user_id=1465747711"
    }
  },
  {
    "follower" : {
      "accountId" : "3007162188",
      "userLink" : "https://twitter.com/intent/user?user_id=3007162188"
    }
  },
  {
    "follower" : {
      "accountId" : "3235129035",
      "userLink" : "https://twitter.com/intent/user?user_id=3235129035"
    }
  },
  {
    "follower" : {
      "accountId" : "2935697118",
      "userLink" : "https://twitter.com/intent/user?user_id=2935697118"
    }
  },
  {
    "follower" : {
      "accountId" : "238621833",
      "userLink" : "https://twitter.com/intent/user?user_id=238621833"
    }
  },
  {
    "follower" : {
      "accountId" : "219485065",
      "userLink" : "https://twitter.com/intent/user?user_id=219485065"
    }
  },
  {
    "follower" : {
      "accountId" : "1300598688",
      "userLink" : "https://twitter.com/intent/user?user_id=1300598688"
    }
  },
  {
    "follower" : {
      "accountId" : "1099358539",
      "userLink" : "https://twitter.com/intent/user?user_id=1099358539"
    }
  },
  {
    "follower" : {
      "accountId" : "821377735",
      "userLink" : "https://twitter.com/intent/user?user_id=821377735"
    }
  },
  {
    "follower" : {
      "accountId" : "469669616",
      "userLink" : "https://twitter.com/intent/user?user_id=469669616"
    }
  },
  {
    "follower" : {
      "accountId" : "364420117",
      "userLink" : "https://twitter.com/intent/user?user_id=364420117"
    }
  }
]