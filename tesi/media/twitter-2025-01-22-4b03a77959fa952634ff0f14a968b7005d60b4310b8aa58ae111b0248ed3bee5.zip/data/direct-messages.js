window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "360730908-1529944674",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sending*",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1076462606339186692",
            "createdAt" : "2018-12-22T13:00:59.760Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sensing 60 usd",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1076462583077654532",
            "createdAt" : "2018-12-22T13:00:54.215Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sure, here it is:\nstefa168@hotmail.it",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1076462069103452165",
            "createdAt" : "2018-12-22T12:58:51.676Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I am going to need your paypal email",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1076459916515258374",
            "createdAt" : "2018-12-22T12:50:18.454Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, I still haven't received any notification of the refund. Is everything alright?",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1076420003753353220",
            "createdAt" : "2018-12-22T10:11:42.503Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That's okay, thank you.\nI wish you happy holidays and a fantastic new year\n\n~Stefano",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1075401393991761926",
            "createdAt" : "2018-12-19T14:44:07.025Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So sorry about everything. I can send the refund later today",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1074925176100409348",
            "createdAt" : "2018-12-18T07:11:47.823Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, I am very, very sorry, but I don't need your service anymore. Please, I'd love to have a refund. There's nothing wrong with the sketch, it looks very good and it is clear you are talented. I'd love to know how to draw as good as you can and I know that this type of work takes a lot of time, but I don't think that it takes over 150 days to manage to contact me after many messages, PMs and e-mails asking just to know about any (even little) progress.",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1074118627727687685",
            "createdAt" : "2018-12-16T01:46:51.708Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/PsQ7ZLq2Wr",
                "expanded" : "https://twitter.com/messages/media/1073991522713042948",
                "display" : "pic.twitter.com/PsQ7ZLq2Wr"
              }
            ],
            "text" : "if there are any changes that needs to be done, let me know https://t.co/PsQ7ZLq2Wr",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1073991522713042948/1073991465477369856/v6-VyoS5.jpg"
            ],
            "senderId" : "1529944674",
            "id" : "1073991522713042948",
            "createdAt" : "2018-12-15T17:21:47.878Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sorry it took so long \n\nhere is the sketch before I continue on with the linework.",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1073991448285065220",
            "createdAt" : "2018-12-15T17:21:29.772Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "In case you cannot fullfill the commission, I would kindly ask for a refund. I'm sorry, but I have waited since the end of August, and you told me that it would have been ready around that period.",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1073597158669078533",
            "createdAt" : "2018-12-14T15:14:43.813Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, how it is going? I haven't heard of you for a month!\nIf there is any problem, just let me know.",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1072463469151223812",
            "createdAt" : "2018-12-11T12:09:51.158Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/htTsC0vjid",
                "expanded" : "https://i.pinimg.com/originals/03/6c/76/036c76099110ae24d4fc13fec74d85ce.jpg",
                "display" : "i.pinimg.com/originals/03/6…"
              },
              {
                "url" : "https://t.co/nFgj97nTc5",
                "expanded" : "http://vignette99.wikia.nocookie.net/forgottenrealms/images/9/93/Anton_Marivaldi.jpg/revision/latest?cb=20170203192825",
                "display" : "vignette99.wikia.nocookie.net/forgottenrealm…"
              },
              {
                "url" : "https://t.co/5Hl169KRgc",
                "expanded" : "https://i.pinimg.com/736x/0c/41/ce/0c41ce0c44e4b0940340d430de9a43c7--character-reference-character-ideas.jpg",
                "display" : "i.pinimg.com/736x/0c/41/ce/…"
              },
              {
                "url" : "https://t.co/fSRswKZedJ",
                "expanded" : "https://78.media.tumblr.com/ce2607ef103c1c86c97bfa00134fffdb/tumblr_nwvl5uqh9o1sazby5o1_500.jpg",
                "display" : "78.media.tumblr.com/ce2607ef103c1c…"
              }
            ],
            "text" : "Sure!\nJust to let you know, in case you need to contact me, you can text me also on Telegram (@Stefa168), in case it is more conveniente for you.\n\nHere's what I wrote you some time ago by e-mail:\nFirst of all: the main armor looks like this robe:\n https://t.co/htTsC0vjid\n however, it has lighter and more vivid colors. You can take inspiration from \n https://t.co/nFgj97nTc5 .\n Her clothes are also adorned with little amounts of gold.\n Just keep in mind that she dowsn’t have the  jewels depicted in the first image, on the neck and on her hands and  forearms, where she wears white bandages\n https://t.co/5Hl169KRgc\n  \n Finally, under the robe, she wears a more narrow pair of pants like the ones depicted here: \n https://t.co/fSRswKZedJ\n\nIf you need more details, let me know, I'll be happy to give more\n~ Stefano",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1060079015594209284",
            "createdAt" : "2018-11-07T07:58:27.394Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I did not. I have not recieved any emails from you. Can you send the reference pictures i asked for through here? Its much appreciated",
            "mediaUrls" : [ ],
            "senderId" : "1529944674",
            "id" : "1060005266157199364",
            "createdAt" : "2018-11-07T03:05:24.128Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I just wanted to ask how it is going and if you had received my last messages...",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1059809334555828228",
            "createdAt" : "2018-11-06T14:06:50.404Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It looks like I am not able to get in touch with you via reddit and email, so I am trying via twitter",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1059808761693593604",
            "createdAt" : "2018-11-06T14:04:33.780Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1529944674",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, I am Stefano from reddit.",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1059808650930331658",
            "createdAt" : "2018-11-06T14:04:07.416Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "360730908-927991406743912448",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [
              {
                "senderId" : "927991406743912448",
                "reactionKey" : "like",
                "eventId" : "1259864360018681857",
                "createdAt" : "2020-05-11T15:14:05.247Z"
              }
            ],
            "urls" : [ ],
            "text" : "thanks!",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259864332277555210",
            "createdAt" : "2020-05-11T15:13:58.653Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "your island is very pretty by the way!",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259864210709905412",
            "createdAt" : "2020-05-11T15:13:29.674Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ahahah",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259864195283202052",
            "createdAt" : "2020-05-11T15:13:25.995Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "we did it ! haha",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259864155399565316",
            "createdAt" : "2020-05-11T15:13:16.484Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "it worked",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259864122008756230",
            "createdAt" : "2020-05-11T15:13:08.542Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yeah",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259864107777495045",
            "createdAt" : "2020-05-11T15:13:05.132Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yea",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863983844188164",
            "createdAt" : "2020-05-11T15:12:35.583Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "we can just trade now no?",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259863918576615435",
            "createdAt" : "2020-05-11T15:12:20.020Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "so we can add as friends",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863858807820293",
            "createdAt" : "2020-05-11T15:12:05.771Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "just go back",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863825630846980",
            "createdAt" : "2020-05-11T15:11:57.862Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok now",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863810720088071",
            "createdAt" : "2020-05-11T15:11:54.334Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [
              {
                "senderId" : "927991406743912448",
                "reactionKey" : "agree",
                "eventId" : "1259863168106606592",
                "createdAt" : "2020-05-11T15:09:21.068Z"
              }
            ],
            "urls" : [ ],
            "text" : "899YN",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863150746361860",
            "createdAt" : "2020-05-11T15:09:16.959Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok !",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259863078788792324",
            "createdAt" : "2020-05-11T15:08:59.803Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'm opening",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863037772795908",
            "createdAt" : "2020-05-11T15:08:50.043Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sure",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259863021947695115",
            "createdAt" : "2020-05-11T15:08:46.242Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "aaah ok lets tru again if you wanna",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259862985876688901",
            "createdAt" : "2020-05-11T15:08:37.672Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😐",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259862928318173189",
            "createdAt" : "2020-05-11T15:08:23.923Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok it looks like we need to visit and leave correctly one's island once",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259862897074765829",
            "createdAt" : "2020-05-11T15:08:16.473Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yes! i got it",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259862237906374663",
            "createdAt" : "2020-05-11T15:05:39.334Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "your username is 'babi' right?",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259862090044575749",
            "createdAt" : "2020-05-11T15:05:04.064Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sent",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259862056376860676",
            "createdAt" : "2020-05-11T15:04:56.042Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "you should receive a notification on the top left",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861916492726278",
            "createdAt" : "2020-05-11T15:04:22.690Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Alright, I'm adding you",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861875237564421",
            "createdAt" : "2020-05-11T15:04:12.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok !",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259861759424421893",
            "createdAt" : "2020-05-11T15:03:45.245Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "the next day you receive it in your mailbox",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861669116882951",
            "createdAt" : "2020-05-11T15:03:23.735Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "and it ends there",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861613722640389",
            "createdAt" : "2020-05-11T15:03:10.547Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sends the item with the letter",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861600003112967",
            "createdAt" : "2020-05-11T15:03:07.246Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "when you send the letter, the game connects to Nintendo's servers",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861550090911749",
            "createdAt" : "2020-05-11T15:02:55.354Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yes, but it hasn't to be a stable connection",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259861475574853645",
            "createdAt" : "2020-05-11T15:02:37.574Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "You need internet for that too right ?",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259861398865182727",
            "createdAt" : "2020-05-11T15:02:19.282Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "however, to do so I have to add you as a friend, if it isn't a problem",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259860728653262852",
            "createdAt" : "2020-05-11T14:59:39.502Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If you want, we can exchange the items by mail",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259860597996486660",
            "createdAt" : "2020-05-11T14:59:08.433Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [
              {
                "senderId" : "360730908",
                "reactionKey" : "agree",
                "eventId" : "1259860798387769349",
                "createdAt" : "2020-05-11T14:59:56.103Z"
              }
            ],
            "urls" : [ ],
            "text" : "im gonna try something wait",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259860549598404612",
            "createdAt" : "2020-05-11T14:58:56.798Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It looks like you have some problems with the NAT settings in your router",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259860460708548612",
            "createdAt" : "2020-05-11T14:58:35.604Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "360730908",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hi!",
            "mediaUrls" : [ ],
            "senderId" : "927991406743912448",
            "id" : "1259860399375212548",
            "createdAt" : "2020-05-11T14:58:20.994Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "927991406743912448",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, It's Stefano from Animal Crossing",
            "mediaUrls" : [ ],
            "senderId" : "360730908",
            "id" : "1259860321931591686",
            "createdAt" : "2020-05-11T14:58:02.734Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]