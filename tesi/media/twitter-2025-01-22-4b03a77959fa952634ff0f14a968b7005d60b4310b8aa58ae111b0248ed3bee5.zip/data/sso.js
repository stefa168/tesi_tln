window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "106133069400425769269",
      "ssoEmail" : "stefa168@hotmail.it",
      "associationMethodType" : "Login",
      "createdAt" : "2022-06-15T15:49:13.878Z"
    }
  }
]