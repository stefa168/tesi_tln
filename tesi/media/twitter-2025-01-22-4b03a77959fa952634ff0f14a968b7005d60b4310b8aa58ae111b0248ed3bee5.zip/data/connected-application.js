window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : "http://twitter.com"
      },
      "name" : "Mobile Web",
      "description" : "Twitter Mobile Web",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2013-08-09T13:41:42.000Z",
      "id" : "49152"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "SoundCloud",
        "url" : "http://soundcloud.com"
      },
      "name" : "SoundCloud",
      "description" : "This application will automatically tweet your new tracks and sets that you upload to SoundCloud. You'll have to register an account on soundcloud.com to use it.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2012-07-27T14:25:44.000Z",
      "id" : "370"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Dropbox"
      },
      "name" : "Dropbox ",
      "description" : "Integrates Twitter with Dropbox",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2012-04-11T15:18:33.000Z",
      "id" : "159387"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Google Inc",
        "url" : "https://www.google.com/",
        "privacyPolicyUrl" : "https://policies.google.com/privacy",
        "termsAndConditionsUrl" : "https://policies.google.com/terms"
      },
      "name" : "Google",
      "description" : "Google/Twitter integration.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2011-08-28T22:09:59.000Z",
      "id" : "8719"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "",
        "url" : ""
      },
      "name" : "Sword & Sworcery EP",
      "description" : "Superbrothers: Sword & Sworcery EP",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2012-09-06T11:00:22.000Z",
      "id" : "1632048"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Gleam.io",
        "url" : "https://gleam.io",
        "privacyPolicyUrl" : "https://gleam.io/privacy",
        "termsAndConditionsUrl" : "https://gleam.io/terms"
      },
      "name" : "Gleam Competition App",
      "description" : "In order to verify your entry to this competition via Twitter we need permissions from your account.",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2021-01-25T12:52:08.000Z",
      "id" : "4206775"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2018-11-08T06:58:31.000Z",
      "id" : "258901"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "The Webby Awards",
        "url" : "https://vote.webbyawards.com",
        "privacyPolicyUrl" : "http://webbyawards.com/privacy-policy/",
        "termsAndConditionsUrl" : "http://webbyawards.com/privacy-policy/"
      },
      "name" : "The Webby People's Voice Awards",
      "description" : "The official app for the 2019 Webby Awards People's Voice.",
      "permissions" : [
        "read",
        "emailaddress"
      ],
      "approvedAt" : "2020-04-30T19:21:18.000Z",
      "id" : "833456"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "Animal Crossing: Pocket Camp",
      "description" : "Relax and enjoy the simple pleasures of camp life...anytime you want!",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2020-01-25T14:59:20.000Z",
      "id" : "14202581"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Gratipay, LLC",
        "url" : "https://gratipay.com/"
      },
      "name" : "Gratipay",
      "description" : "Weekly payments, motivated by gratitude",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2014-08-28T10:12:29.000Z",
      "id" : "3213537"
    }
  }
]